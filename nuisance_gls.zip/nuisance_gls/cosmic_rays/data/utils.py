from dataclasses import dataclass
from enum import Enum
from typing import List

import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from multiprocessing import Pool

def angle_line(azimuth, zenith):
  ref_length = 100_000
  if zenith == 0:
    return (0, 0)
  
  length = ref_length * np.sin(zenith)
  return (-length * np.sin(-azimuth), -length * np.cos(azimuth))
  
class ParticleType(Enum):
  PHOTON = 0
  MESON = 1
  BARYON = 2
  LEPTON = 3
  UNKNOWN = 4

@dataclass
class Particle:
  id: int
  name: str
  charge: int
  particle_type: ParticleType

particle_list = [
  Particle(1, "gamma", 0, ParticleType.PHOTON),
  Particle(2, "positron", 1, ParticleType.LEPTON),
  Particle(3, "electron", -1, ParticleType.LEPTON),
  Particle(5, "muon+", 1, ParticleType.LEPTON),
  Particle(6, "muon-", -1, ParticleType.LEPTON),
  Particle(7, "pion", 0, ParticleType.MESON),
  Particle(8, "pion+", 1, ParticleType.MESON),
  Particle(9, "pion-", -1, ParticleType.MESON),
  Particle(10, "kaon_long", 0, ParticleType.MESON),
  Particle(11, "kaon+", 1, ParticleType.MESON),
  Particle(12, "kaon-", -1, ParticleType.MESON),
  Particle(13, "neutron", 0, ParticleType.BARYON),
  Particle(14, "proton", 1, ParticleType.BARYON),
  Particle(15, "antiproton", -1, ParticleType.BARYON),
  Particle(16, "kaon_short", 0, ParticleType.MESON),
  Particle(17, "eta?", 0, ParticleType.UNKNOWN),
  Particle(18, "lambda", 0, ParticleType.BARYON),
  Particle(19, "sigma+", 1, ParticleType.BARYON),
  Particle(20, "sigma", 0, ParticleType.BARYON),
  Particle(21, "sigma-", -1, ParticleType.BARYON),
  Particle(22, "xi", 0, ParticleType.BARYON),
  Particle(23, "xi-", -1, ParticleType.BARYON),
  Particle(24, "omega-", -1, ParticleType.BARYON),
  Particle(25, "antineutron", 0, ParticleType.BARYON),
  Particle(26, "antilambda", 0, ParticleType.BARYON),
  Particle(27, "antisigma-", -1, ParticleType.BARYON),
  Particle(28, "antisigma", 0, ParticleType.BARYON),
  Particle(29, "antisigma+", 1, ParticleType.BARYON),
  Particle(30, "antixi", 0, ParticleType.BARYON),
  Particle(31, "antixi+", 1, ParticleType.BARYON),
  Particle(32, "antiomega+", 1, ParticleType.BARYON),
  Particle(50, "omega_meson", 0, ParticleType.MESON),
  Particle(51, "rho", 0, ParticleType.MESON),
  Particle(52, "rho+", 1, ParticleType.MESON),
  Particle(53, "rho-", -1, ParticleType.MESON),
  Particle(54, "delta++", 2, ParticleType.BARYON),
  Particle(55, "delta+", 1, ParticleType.BARYON),
  Particle(56, "delta", 0, ParticleType.BARYON),
  Particle(57, "delta-", -1, ParticleType.BARYON),
  Particle(58, "antidelta--", -2, ParticleType.BARYON),
  Particle(59, "antidelta-", -1, ParticleType.BARYON),
  Particle(60, "antidelta", 0, ParticleType.BARYON),
  Particle(61, "antidelta+", 1, ParticleType.BARYON),
]

class CosmicRayEvent:
  particle_dict = {p.id : p for p in particle_list}
  particle_muons = [5, 6]
  
  def __init__(self, primary_id, azimuth, zenith, energy, x, y, t, secondary_ids, secondary_momenta) -> None:
    self.primary_id = primary_id
    self.azimuth = azimuth
    self.zenith = zenith
    self.energy = energy
    self.x = x
    self.y = y
    self.t = t 
    self.secondary_ids = secondary_ids
    self.secondary_momenta = secondary_momenta
    
  @classmethod 
  def from_h5(cls, source_h5, event_id, primary_particle_id):
    """This transforms coordinates such that positive y is north

    Args:
        source_h5 (_type_): _description_
        event_id (_type_): _description_
        primary_particle_id (_type_): _description_

    Returns:
        _type_: _description_
    """
    raw_event = source_h5[f'event_{event_id}']
    return cls(
      primary_id = primary_particle_id,
      azimuth = source_h5['event_info']['azimuth'][event_id-1],
      zenith = source_h5['event_info']['zenith'][event_id-1],
      energy = source_h5['event_info']['event_energy'][event_id-1],
      x = -np.array(raw_event['y']),
      y = np.array(raw_event['x']),
      t = np.array(raw_event['t']),
      secondary_ids = np.array(raw_event['particle_type']),
      secondary_momenta = np.array(raw_event['mom'])
    )
  
  def secondary_counts(self):
    return np.unique(self.secondary_ids, return_counts=True)
  
  def secondary_positions(self, particle_ids: List[int] = None):
    if particle_ids is not None:
      indices = np.nonzero(np.isin(self.secondary_ids, particle_ids))
      return np.column_stack([self.x[indices], self.y[indices]])
    else:
      return np.column_stack([self.x, self.y])
    
  def secondary_mask(self, particle_ids: List[int]):
    return np.nonzero(np.isin(self.secondary_ids, particle_ids))

    
  def plot_particle(
    self, 
    time_trim: float, 
    title_note: str, 
    sample_prop=None,
    manual_title=None, 
    my_ax=None, 
    figsize=(20,20), 
    fontsize=20, 
    ax_lim=2500, 
    secondary_types: List[int]=None, 
    show_lines=True
  ):
    
    mask = (self.t < np.quantile(self.t, 1-time_trim/2)) & (self.t > np.quantile(self.t, time_trim/2))
    if secondary_types is not None:
      mask = mask & np.isin(self.secondary_ids, secondary_types)
      
    if sample_prop is not None:
      mask = mask & np.random.binomial(1, sample_prop, mask.shape).astype(bool)

    if my_ax is None:
      fig = plt.figure(figsize=figsize)
      ax = fig.gca()
    else:
      ax = my_ax
    ax.set_aspect('equal', adjustable='box')
    
    if self.x[mask].size == 0:
      return

    event_plot = ax.scatter(self.x[mask], self.y[mask], c = self.t[mask], s = 1.5, cmap="plasma")
    cbar = plt.colorbar(event_plot, fraction=0.046, pad=0.04, label="Time (ns)", ax=ax)
    cbar.set_label("Time (ns)", fontsize=fontsize)
    
    if show_lines:
      if self.x[mask].size > 5:
        pca = PCA(n_components=2)
        pca.fit(np.column_stack([self.x[mask], self.y[mask]]))
        pca_com = pca.components_
        pca_var = pca.explained_variance_ratio_
        ax.plot([0, pca_com[0][0] * 4000 * pca_var[0]], [0, pca_com[0][1] * 4000 * pca_var[0]], c="red")
        ax.plot([0, pca_com[1][0] * 4000 * pca_var[0]], [0, pca_com[1][1] * 4000 * pca_var[0]], c="blue")
        
        arrow, _ = self.get_arrow_of_time(mask)
        ax.plot([0, arrow[0] * 4000], [0, arrow[1] * 4000], c="green")
        
      attack_angle = angle_line(self.azimuth, self.zenith)
      ax.plot([0, attack_angle[0]], [0, attack_angle[1]], c="black")
    
    ax.set_xlabel("x (meters)", fontsize=fontsize)
    ax.set_ylabel("y (meters)", fontsize=fontsize)
    ax.set_xlim(-ax_lim, ax_lim)
    ax.set_ylim(-ax_lim, ax_lim)
    
    title = f"Position of secondary particles (Azimuth {round(self.azimuth, 3)}, Zenith {round(self.zenith, 3)}, Energy {round(self.energy, 3)})\n" \
                f"Black line shows direction of primary particle. Flat length is 100,000 m\n" \
                f"Red and Blue lines indicate 1st and 2nd PCA components, scaled according to variance explained{title_note}"
    ax.set_title(title if manual_title is None else manual_title, fontsize=fontsize)
  
  def get_arrow_of_time(self, mask=None):
    if mask is None:
      mask_x, mask_y, mask_t = self.x, self.y, self.t
    else:
      mask_x, mask_y, mask_t = self.x[mask], self.y[mask], self.t[mask]
      

    location = np.column_stack((mask_x, mask_y))
    coefs = LinearRegression().fit(location, mask_t).coef_
    time_arrow = coefs/np.linalg.norm(coefs, ord=2)
    
    arrow_projection = (location * time_arrow).sum(axis=-1)
    height_slope = LinearRegression().fit(arrow_projection.reshape(-1, 1), mask_t).coef_[0]
    return time_arrow, height_slope
  
  def get_summary_stats(self):
    return_dict = {
      "energy": self.energy,
      "zenith": self.zenith,
      "azimuth": self.azimuth,
      "num_secondary": len(self.secondary_ids),
      "mom_all": self.secondary_momenta.sum()
    }
    
    positions = self.secondary_positions()
    footprint_pca = PCA(n_components=2).fit(positions)
    return_dict["pca_ev1_all"] = footprint_pca.explained_variance_[0]
    return_dict["pca_ev2_all"] = footprint_pca.explained_variance_[1]
    
    time_arrow, time_slope = self.get_arrow_of_time()
    return_dict["time_azimuth"] = np.arctan2(-time_arrow[0], time_arrow[1])
    return_dict["time_zenith"] = np.arctan(time_slope)
    
    for particle_id in self.particle_dict:
      
      positions = self.secondary_positions([particle_id])
      return_dict["prop_" + str(particle_id)] = len(positions)/len(self.secondary_ids)
      return_dict["mom_" + str(particle_id)] = self.secondary_momenta[self.secondary_mask([particle_id])].sum()
      return_dict["pca_ev1_" + str(particle_id)] = np.nan
      return_dict["pca_ev2_" + str(particle_id)] = np.nan

      if positions.shape[0] < 10:
        continue
      
      footprint_pca = PCA(n_components=2).fit(positions)
      return_dict["pca_ev1_" + str(particle_id)] = footprint_pca.explained_variance_[0]
      return_dict["pca_ev2_" + str(particle_id)] = footprint_pca.explained_variance_[1]
    
    level_sets = self.level_sets()
    for ls in range(5, 100, 5):
      return_dict[f"ls_{ls}"] = level_sets[ls]
    
    return return_dict
  
  def level_sets(self):
    norms = np.linalg.norm(np.column_stack((self.x, self.y)), 2, axis=-1).flatten()
    norms.sort()
    indices = np.floor(np.linspace(0, 1, 101, True) * len(self.x))[1:].astype(int) - 1
    return norms[indices]
  
  def export_features(self, channels: List[List[int]], pca_channels: List[List[int]], tile_size):
    
    max_range = max(np.max(np.abs(self.x)), np.max(np.abs(self.y)))
    grid_length = int(2 * (max_range // tile_size + 1)) # squares of side length
    max_grid_range = grid_length // 2 * tile_size # in meters
    
    def get_squares_counts(p_x, p_y):
      """Bins start from the top left, and go in reading order

      Args:
          p_x (_type_): _description_
          p_y (_type_): _description_

      Returns:
          _type_: _description_
      """
      secondary_subset = np.column_stack((-p_x, p_y))
      secondary_subset = np.floor((max_grid_range - secondary_subset)/tile_size).astype(int)
      secondary_subset = (grid_length * secondary_subset[:, 1] + secondary_subset[:, 0])
      l_bin_count = np.bincount(secondary_subset)
      l_bin_indices = np.flatnonzero(l_bin_count)
      
      return l_bin_indices.astype(np.uint32), l_bin_count[l_bin_indices].astype(np.uint32)
    
    return_dict = {
      "channels": channels,
      "pca_channels": pca_channels,
      "tile_size": tile_size,
      "grid_length": grid_length,
      "num_secondary": len(self.secondary_ids),
      "mom_secondary": self.secondary_momenta.sum(),
      "time_range": np.max(self.t) - np.min(self.t),
      "level_sets": self.level_sets(),
      "bin_indices": list(),
      "bin_counts": list()
    }
    
    time_arrow, time_slope = self.get_arrow_of_time()
    return_dict["time_azimuth"] = np.arctan2(-time_arrow[0], time_arrow[1])
    return_dict["time_slope"] = time_slope
    
    positions = self.secondary_positions()
    footprint_pca = PCA(n_components=2).fit(positions)
    return_dict["pca_rev1_all"] = np.sqrt(footprint_pca.explained_variance_[0])
    return_dict["pca_rev2_all"] = np.sqrt(footprint_pca.explained_variance_[1])
    
    # PCA Channels
    for cid, channel in enumerate(pca_channels):
      positions = self.secondary_positions(channel)
      footprint_pca = PCA(n_components=2).fit(positions)
      return_dict[f"pca_ev1_{cid}"] = np.sqrt(footprint_pca.explained_variance_[0])
      return_dict[f"pca_ev2_{cid}"] = np.sqrt(footprint_pca.explained_variance_[1])
    
    # Channels
    for cid, channel in enumerate(channels):
      positions = self.secondary_positions(channel)
      return_dict[f"prop_{cid}"] = len(positions)/len(self.secondary_ids)
      return_dict[f"mom_{cid}"] = self.secondary_momenta[self.secondary_mask(channel)].sum()
      
      
    # Remainder channel
    all_channels = sum(channels, [])
    remainder_channels = [pid for pid in self.particle_dict if pid not in all_channels]
    positions = self.secondary_positions(remainder_channels)
    return_dict[f"prop_r"] = len(positions)/len(self.secondary_ids)
    return_dict[f"mom_r"] = self.secondary_momenta[self.secondary_mask(remainder_channels)].sum()

    
    # image
    total_channel_mask = np.zeros(len(self.x)).astype(bool)
    
    for channel in channels:
      channel_mask = np.isin(self.secondary_ids, channel)
      total_channel_mask = np.logical_or(total_channel_mask, channel_mask)
      
      mask = channel_mask 
      bin_indices, bin_counts = get_squares_counts(self.x[mask], self.y[mask])
      return_dict["bin_indices"].append(bin_indices)
      return_dict["bin_counts"].append(bin_counts)
      
    mask = ~total_channel_mask 
    bin_indices, bin_counts = get_squares_counts(self.x[mask], self.y[mask])
    return_dict["bin_indices"].append(bin_indices)
    return_dict["bin_counts"].append(bin_counts)
  
    return return_dict
          

def get_particle_by_id(id: int):
  return CosmicRayEvent.particle_dict.get(id, Particle(-1, "Other", 0, ParticleType.UNKNOWN))


def conditional_proportions(metric, label, low, high, width, gamma_df, proton_df, fontsize=20):
  bins = np.arange(low, high, width)
  counts = {"gamma": [0] * (len(bins) - 1), "proton" : [0] * (len(bins) - 1)}

  for is_gamma in [True, False]:
    df = gamma_df if is_gamma else proton_df
    for i in df.index:
      for b in range(len(bins) -1 ):
        if df.loc[i, metric] >= bins[b] and df.loc[i, metric] < bins[b+1]:
          counts["gamma" if is_gamma else "proton"][b] += 1
          
  counts["prop_gamma"] = [0 if g + p == 0 else g/(g + p) for (g, p) in zip(counts["gamma"], counts["proton"])]

  fig, ax = plt.subplots(2, 1, figsize=(10, 9))
  plt.subplots_adjust(hspace=0.4)

  ax[0].bar((bins + width/2)[:-1], counts["prop_gamma"], width=width, edgecolor = "black")
  ax[0].set_title(f"P(gamma ray | {label})", fontsize=fontsize)
  ax[0].set_ylabel("Prop. Gamma Rays", fontsize=fontsize)
  ax[0].set_xlabel(label, fontsize=fontsize)
  ax[0].tick_params(axis='both', labelsize=fontsize)

  ax[1].bar((bins + width/2)[:-1], counts["gamma"], label="gamma", width=width, edgecolor = "black")
  ax[1].bar((bins + width/2)[:-1], counts["proton"], label="proton", width=width, edgecolor = "black", alpha = 0.5)
  ax[1].set_title(f"Count of events by {label}", fontsize=fontsize)
  ax[1].set_ylabel("Empirical Counts", fontsize=fontsize)
  ax[1].set_xlabel(label, fontsize=fontsize)
  ax[1].legend(fontsize=fontsize)
  ax[1].tick_params(axis='both', labelsize=fontsize)
  
  