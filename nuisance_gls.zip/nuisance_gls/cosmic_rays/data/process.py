from typing import List, Sequence
from tqdm import tqdm
import pickle

import numpy as np
import torch


class CrDataItem:

    def __init__(
        self, 
        is_gamma: int, 
        energy: float, 
        zenith: float, 
        azimuth: float, 
        grid_x, 
        grid_y, 
        grid_length, 
        bin_indices, 
        bin_counts
    ):
        self.is_gamma = is_gamma
        self.energy = energy
        self.zenith = zenith
        self.azimuth = azimuth
        self.grid_x = grid_x
        self.grid_y = grid_y 
        self.grid_length = grid_length
        
        self.sensor_features = self.sensor_subset(bin_indices, bin_counts)
        
    def sensor_subset(self, bin_indices, bin_counts):
        grid_coordinates = np.column_stack((-self.grid_x, self.grid_y))
        grid_coordinates = self.grid_length/2 - grid_coordinates
        sensor_bin_indices = (self.grid_length * grid_coordinates[:, 1] + grid_coordinates[:, 0]).astype(int)
        sensor_hits = list()
        for cid in range(len(bin_indices)):
            for bin_index in sensor_bin_indices:
                search_for_bin = bin_indices[cid] == bin_index
                if np.any(search_for_bin):
                    sensor_hits.append(bin_counts[cid][search_for_bin][0])
                else:
                    sensor_hits.append(0)
        return torch.Tensor(sensor_hits)


class CrDataset(torch.utils.data.Dataset):
    zenith_scale = 65 * np.pi/180
    azimuth_scale = np.pi
    energy_scale = 1e7
  
    def __init__(self, items: List[CrDataItem]):
        print("creating dataset")
        self.items = items
        self.num_features = self.items[0].sensor_features.shape[-1]
    
    def __len__(self):
        return len(self.items)
  
    def __getitem__(self, idx: int):
        return {
            'energy': self.items[idx].energy/CrDataset.energy_scale,
            'zenith': self.items[idx].zenith/CrDataset.zenith_scale,
            'azimuth': self.items[idx].azimuth/CrDataset.azimuth_scale,
            'is_gamma': self.items[idx].is_gamma, 
            'features': (self.items[idx].sensor_features - self.feature_mean) / self.feature_scale,
        }
  
  

    def set_scale(self, feature_scale = None):
        features = torch.stack([item.sensor_features for item in self.items], dim=0)
        
        self.feature_mean = 0
        self.feature_scale = features.max(dim=0).values if feature_scale is None else feature_scale
        self.feature_scale = torch.maximum(self.feature_scale, torch.ones(features.shape[-1]))
        return self.feature_scale


def process_files(
    file_ids: Sequence[int],
    workspace: str,  # data location
    grid_x: np.ndarray,  # detectors location
    grid_y: np.ndarray
):
    data_points: List[CrDataItem] = list()
    for is_gamma in [True, False]:
        print(f"Processing {'gamma' if is_gamma else 'hadron'} files")
        for file_id in tqdm(file_ids):
            filename = workspace + f"DAT{'10' if is_gamma else '14'}0{str(file_id).rjust(3, '0')}.pkl"
            with open(filename, "rb") as file:
                data = pickle.load(file)

            for key_id, event_id in enumerate(data):
                event = data[event_id]
                event_features = data[event_id]['features']

                repeat = 1 if event['energy'] > 200_000 else 1
                for _ in range(repeat):
                    data_points.append(CrDataItem(
                        is_gamma=int(is_gamma),
                        energy=event['energy'], 
                        zenith=event['zenith'], 
                        azimuth=event['azimuth'], 
                        grid_x=grid_x,
                        grid_y=grid_y,
                        bin_indices=event_features['bin_indices'],
                        bin_counts=event_features['bin_counts'],
                        grid_length=event_features["grid_length"]
                    ))
            
    print(f"total: {len(data_points)}")
    print(f"total gammas: {len([item for item in data_points if item.is_gamma])}")
    print(f"total protons: {len([item for item in data_points if not item.is_gamma])}")
    print(f"unique energy: {len(np.unique([item.energy for item in data_points]))}")
    return data_points
