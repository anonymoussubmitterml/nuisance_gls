import numpy as np

from corsikaio import CorsikaParticleFile
from corsikaio import as_dict

from tqdm import tqdm

import h5py
from astropy.table import QTable

import sys

def table_to_h5(table, filename, groupname='data'):
    """
    Write an Astropy Table object to an HDF5 filevent.

    Parameters
    ----------
    table : `~astropy.tablevent.Table`
        The table to write to the HDF5 filevent.
    filename : str
        The name of the HDF5 file to write to.
    groupname : str, optional
        The name of the HDF5 group to write the table to. Default is 'data'.

    Returns
    -------
    None

    Examples
    --------
    >>> from astropy.table import QTable
    >>> import numpy as np
    >>> data = QTable({'x': [1, 2, 3], 'y': [4, 5, 6]}, meta={'unit': {'x': 'cm', 'y': 'm'}})
    >>> table_to_h5(data, 'data.h5', groupname='my_group')
    """
    # Open the HDF5 file for writing
    with h5py.File(filename, 'a') as f:
        # Create a new HDF5 group for the table
        group = f.create_group(groupname)
        # Write the table columns to the group as datasets
        for colname in table.colnames:
            data = table[colname]
            group.create_dataset(colname, data=data, dtype=data.dtype)
    
    
    
# ----- CODE STARTS HERE -----

assert len(sys.argv) > 1, "Input file must be specified"

input_file = str(sys.argv[1])
out_file = str(sys.argv[2])


# Initialize meta arrays

sel_events = 100 # number of events to store in file

evt_energy = np.empty(sel_events)
azimuth = np.empty(sel_events)
zenith = np.empty(sel_events)

with CorsikaParticleFile(input_file) as f:
    # for ievt in tqdm(range(sel_events), desc='Converting events: ', ascii=True):
    with tqdm(desc='Converting events: ') as pbar:
        ievt = 0
        while True:
            try:
                event = next(f)
            except IOError as e:
                print(f"truncated at {ievt}")
                break
            except StopIteration as e:
                print(f"All {ievt} events converted")
                break
            evt_energy[ievt] = as_dict(event.header)['total_energy']
            azimuth[ievt] = as_dict(event.header)['azimuth']
            zenith[ievt] = as_dict(event.header)['zenith']
            
            energy = np.sqrt( np.array(as_dict(event.particles)['px'])**2+np.array(as_dict(event.particles)['py'])**2+np.array(as_dict(event.particles)['pz'])**2 )
            
            data = QTable({
                    'particle_type': np.array( 1e-3*as_dict(event.particles)['particle_description'],dtype='int16' ),
                    'x': np.array( 1e-2*as_dict(event.particles)['x'],dtype='float32' ), # from cm to m
                    'y': np.array( 1e-2*as_dict(event.particles)['y'], dtype='float32' ), # from cm to m
                    't': np.array( as_dict(event.particles)['t'], dtype='float32' ), # nanoseconds
                    'mom': energy
                    } 
                )
            
            table_to_h5(data, out_file, groupname='event_'+str(ievt+1))  
            ievt += 1
            pbar.update()
    
    with h5py.File(out_file, 'a') as f:
        group = f.create_group('event_info')
        group.create_dataset('event_energy', data=evt_energy, dtype='float64')
        group.create_dataset('zenith', data=zenith, dtype='float64')
        group.create_dataset('azimuth', data=azimuth, dtype='float64')