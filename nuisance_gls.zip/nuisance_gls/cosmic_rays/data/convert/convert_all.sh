#!/bin/bash

python3 convert_to_image.py /datadrive/workspace/proton_high.h5 proton_high_train.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/proton_low.h5 proton_low_train.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma.h5 gamma_train.pkl --tile-size 2 --is-gamma true --overwrite

python3 convert_to_image.py /datadrive/workspace/proton_cal.h5 proton_cal.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma_cal.h5 gamma_cal.pkl --tile-size 2 --is-gamma true --overwrite

python3 convert_to_image.py /datadrive/workspace/proton_cal2.h5 proton_cal2.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma_cal2.h5 gamma_cal2.pkl --tile-size 2 --is-gamma true --overwrite

python3 convert_to_image.py /datadrive/workspace/proton_cal3.h5 proton_cal3.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma_cal3.h5 gamma_cal3.pkl --tile-size 2 --is-gamma true --overwrite

python3 convert_to_image.py /datadrive/workspace/proton_cal4.h5 /datadrive/workspace/proton_cal4.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma_cal4.h5 /datadrive/workspace/gamma_cal4.pkl --tile-size 2 --is-gamma true --overwrite

python3 convert_to_image.py /datadrive/workspace/proton_diag.h5 proton_diag.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma_diag.h5 gamma_diag.pkl --tile-size 2 --is-gamma true --overwrite

python3 convert_to_image.py /datadrive/workspace/proton_diag2.h5 /datadrive/workspace/proton_diag2.pkl --tile-size 2 --is-gamma false --overwrite
python3 convert_to_image.py /datadrive/workspace/gamma_diag2.h5 /datadrive/workspace/gamma_diag2.pkl --tile-size 2 --is-gamma true --overwrite
