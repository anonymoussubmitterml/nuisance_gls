import numpy as np

from corsikaio import CorsikaParticleFile
from corsikaio import as_dict

from tqdm import tqdm

import h5py
from astropy.table import QTable

import sys

def table_to_h5(table, filename, groupname='data'):
    """
    Write an Astropy Table object to an HDF5 filevent.

    Parameters
    ----------
    table : `~astropy.tablevent.Table`
        The table to write to the HDF5 filevent.
    filename : str
        The name of the HDF5 file to write to.
    groupname : str, optional
        The name of the HDF5 group to write the table to. Default is 'data'.

    Returns
    -------
    None

    Examples
    --------
    >>> from astropy.table import QTable
    >>> import numpy as np
    >>> data = QTable({'x': [1, 2, 3], 'y': [4, 5, 6]}, meta={'unit': {'x': 'cm', 'y': 'm'}})
    >>> table_to_h5(data, 'data.h5', groupname='my_group')
    """
    # Open the HDF5 file for writing
    with h5py.File(filename, 'a') as f:
        # Create a new HDF5 group for the table
        group = f.create_group(groupname)
        # Write the table columns to the group as datasets
        for colname in table.colnames:
            data = table[colname]
            group.create_dataset(colname, data=data, dtype=data.dtype)
    
    
    
# ----- CODE STARTS HERE -----

assert len(sys.argv) > 1, "Data type needs to be specified! \n Enter either 'gamma' or 'proton' for desired data type"

data_type = str(sys.argv[1])

input_files = {
    # 'proton':"/storage/gpfs_data/ctalocal/ctaplus/corsika/prod4/proton/100TeVto1PeV/zd0tozd65/DAT140200",
    # 'gamma':"/storage/gpfs_data/ctalocal/ctaplus/corsika/prod4/gamma/100TeV/zd20/DAT100200"
    'gamma_diag':"/datadrive/workspace/DAT100000_prod6.dat",
    'proton_diag':"/datadrive/workspace/DAT140000_prod6.dat",
    'gamma_cal':"/datadrive/workspace/DAT100001_prod6.dat", # 100 evnts each
    'proton_cal':"/datadrive/workspace/DAT140001_prod6.dat",
    'gamma_cal2':"/datadrive/workspace/DAT100002_migrated.dat", # 100 evnts each
    'proton_cal2':"/datadrive/workspace/DAT140002_migrated.dat",
    'gamma_cal3':"/datadrive/workspace/DAT100003_migrated.dat", # 100 evnts each
    'proton_cal3':"/datadrive/workspace/DAT140003_migrated.dat",
    'gamma_cal4':"/datadrive/workspace/DAT100004_migrated.dat", # 100 evnts each
    'proton_cal4':"/datadrive/workspace/DAT140004_migrated.dat",
    'gamma_diag2':"/datadrive/workspace/DAT100005_migrated.dat", # 100 evnts each
    'proton_diag2':"/datadrive/workspace/DAT140005_migrated.dat"
}

# Initialize meta arrays

sel_events = 100 # number of events to store in file

evt_energy = np.empty(sel_events)
azimuth = np.empty(sel_events)
zenith = np.empty(sel_events)

with CorsikaParticleFile(input_files[data_type]) as f:
    for ievt in tqdm(range(sel_events), desc='Converting events: ', ascii=True):
        try:
            event = next(f)
        except IOError as e:
            print(f"truncated at {ievt}")
            break
        evt_energy[ievt] = as_dict(event.header)['total_energy']
        azimuth[ievt] = as_dict(event.header)['azimuth']
        zenith[ievt] = as_dict(event.header)['zenith']
        
        energy = np.sqrt( np.array(as_dict(event.particles)['px'])**2+np.array(as_dict(event.particles)['py'])**2+np.array(as_dict(event.particles)['pz'])**2 )
        
        data = QTable({
                'particle_type': np.array( 1e-3*as_dict(event.particles)['particle_description'],dtype='int16' ),
                'x': np.array( 1e-2*as_dict(event.particles)['x'],dtype='float32' ), # from cm to m
                'y': np.array( 1e-2*as_dict(event.particles)['y'], dtype='float32' ), # from cm to m
                't': np.array( as_dict(event.particles)['t'], dtype='float32' ), # nanoseconds
                'mom': energy
                } 
            )
        
        table_to_h5(data, data_type+'.h5', groupname='event_'+str(ievt+1))  
    
    with h5py.File(data_type+'.h5', 'a') as f:
        group = f.create_group('event_info')
        group.create_dataset('event_energy', data=evt_energy, dtype='float64')
        group.create_dataset('zenith', data=zenith, dtype='float64')
        group.create_dataset('azimuth', data=azimuth, dtype='float64')