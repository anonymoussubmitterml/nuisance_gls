import argparse
import h5py
from tqdm import tqdm
from multiprocessing import Pool
from ..utils import CosmicRayEvent
import pickle as pkl
import traceback

parser = argparse.ArgumentParser(
        description="Converts raw CORSIKA events to image data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

parser.add_argument(
    "file",
    type=str,
    help='File to convert'
)

parser.add_argument(
    "outpath",
    type=str,
    help='Path to write results'
)

parser.add_argument(
    "--tile-size",
    type=int,
    required=True,
    help='Tile size in meters'
)

parser.add_argument(
    "--is-gamma",
    type=bool,
    required=True,
    help='Does the file contain gamma rays?'
)

parser.add_argument(
    "--overwrite",
    action='store_true',
    help='overwrite existing file?'
)

args = parser.parse_args()


raw_file = h5py.File(args.file)
max_event_id = max([int(s[6:]) for s in list(raw_file.keys())[:-1]])

try:
  try:
    if args.overwrite:
      print(f"Force overwriting of outpath {args.outpath}")
      raise FileNotFoundError()
    with open(args.outpath, "rb") as file:
      build_dict = pkl.load(file)
      print("Existing file found, appending")
  except FileNotFoundError as e:
    build_dict = dict()

  def convert_event_to_image(p_event_id):
    if p_event_id in build_dict:
      return p_event_id, None
    event = CosmicRayEvent.from_h5(raw_file, p_event_id, 1 if args.is_gamma else 14)
    return p_event_id, {
      "primary_identity": event.primary_id,
      "energy": event.energy,
      "azimuth": event.azimuth,
      "zenith": event.zenith,
      "features": event.export_features([[1], [2, 3], [5, 6]], [[1], [2, 3]], args.tile_size)
    }



  with Pool(processes=8) as pool:
    with tqdm(total=max_event_id, desc=f"Converting {args.file}") as prog:
      for event_id, event_data in pool.imap(convert_event_to_image, range(1, max_event_id+1), chunksize=10):
        prog.update()
        if event_data is not None:
          build_dict[event_id] = event_data
  
except Exception as e:
  print(traceback.format_exc())
  print(f"Event id {event_id} failed")
finally:
  with open(args.outpath, "wb") as file:
    pkl.dump(build_dict, file)
