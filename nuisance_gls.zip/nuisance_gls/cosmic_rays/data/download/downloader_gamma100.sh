#!/bin/bash 

for i in $(seq -f "%03g" 364 400)
do
    wget --ca-certificate /tmp/GEANTeScienceSSLCA4.pem --header="Authorization: Bearer $(oidc-token corsika)" https://xfer-archive.cr.cnaf.infn.it:8443/swgo/corsika/corsika_files/gamma/100TeV_10PeV/zd0toza65/DAT100$i -O /datadrive/new_raw/temp_gamma100.dat
    python3 ~/ada-sbi-cosmic-rays/convert_corsika_auto.py /datadrive/new_raw/temp_gamma100.dat /datadrive/new_h5/temp_gamma100.h5
    python3 ~/ada-sbi-cosmic-rays/convert_to_image.py /datadrive/new_h5/temp_gamma100.h5 /datadrive/new_pkl/DAT100$i.pkl --tile-size 2 --is-gamma false --overwrite
    rm /datadrive/new_h5/temp_gamma100.h5
done