#!/bin/bash 

for i in $(seq -f "%03g" 0 499)
do
    wget --ca-certificate /tmp/GEANTeScienceSSLCA4.pem --header="Authorization: Bearer $(oidc-token corsika)" https://xfer-archive.cr.cnaf.infn.it:8443/swgo/corsika/corsika_files/proton/100TeV_10PeV/zd0tozd65/DAT140$i -O /datadrive/new_raw/temp_proton.dat
    python3 ~/ada-sbi-cosmic-rays/convert_corsika_auto.py /datadrive/new_raw/temp_proton.dat /datadrive/new_h5/temp_proton.h5
    python3 ~/ada-sbi-cosmic-rays/convert_to_image.py /datadrive/new_h5/temp_proton.h5 /datadrive/new_pkl/DAT140$i.pkl --tile-size 2 --is-gamma false --overwrite
    rm /datadrive/new_h5/temp_proton.h5
done