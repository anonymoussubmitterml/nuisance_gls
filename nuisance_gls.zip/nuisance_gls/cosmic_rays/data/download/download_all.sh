#!/bin/bash

scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/proton_high_train.pkl proton_high_train.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/proton_low_train.pkl proton_low_train.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/gamma_train.pkl gamma_train.pkl

scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/gamma_cal.pkl gamma_cal.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/gamma_cal2.pkl gamma_cal2.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/gamma_cal3.pkl gamma_cal3.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/proton_cal.pkl proton_cal.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/proton_cal2.pkl proton_cal2.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/proton_cal3.pkl proton_cal3.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/gamma_diag.pkl gamma_diag.pkl
scp -i ~/.ssh/desktop_id alexshen_desktop@51.12.216.221:~/ada-sbi-cosmic-rays/proton_diag.pkl proton_diag.pkl

