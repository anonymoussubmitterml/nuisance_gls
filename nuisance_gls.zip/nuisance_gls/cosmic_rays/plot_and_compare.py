import sys
sys.path.append('..')
import pickle
import click
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.pyplot import cm
from matplotlib.legend_handler import HandlerTuple
import seaborn as sns
from sklearn.metrics import roc_curve
from scipy import stats
from common.test_statistic import BayesFactor


@click.group()
def main():
    pass


@main.command()
def plot():
    with open('./data/split_data.pkl', 'rb') as f:
        d = pickle.load(f)
        train_set, calibration_set, test_set = d['train_set'], d['calibration_set'], d['test_set']
    with open('./results/pickles/allNu_bergerCutoff/calibrated_reject_probs_model.pkl', 'rb') as f:
        calibrated_reject_probs_model = pickle.load(f)
    with open('./data/augment_calib_data.pkl', 'rb') as f:
        d = pickle.load(f)
        calib_inputs, rejection_indicators = d['calib_inputs'], d['rejection_indicators']

    X_test, nu_test, y_test = test_set.drop(columns=['energy', 'azimuth', 'zenith', 'is_gamma']).values, test_set.loc[:, ['energy', 'azimuth', 'zenith']].values, test_set.loc[:, 'is_gamma'].values

    with open('./results/pickles/allNu_infCutoff/catgb_clf_nuEonly.pkl', 'rb') as f:
        cat_gb = pickle.load(f)
    with open('./results/pickles/allNu_infCutoff/setClf_alpha.pkl', 'rb') as f:
        results_df_conservative = pickle.load(f)
    with open('./results/pickles/allNu_bergerCutoff/setClf_alpha.pkl', 'rb') as f:
        results_df_naps = pickle.load(f)

    alpha_grid = np.array([0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1, 0.05, 0.01])

    ## ROC
    grid_size = 100_000
    c_grid = np.linspace(-12, 12, grid_size)

    colors = cm.Blues(np.linspace(0.35, 0.9, 4))
    linestyles = ['dotted', 'dashed', (5, (10, 3)), (0, (3, 1, 1, 1))]
    energies = [125_000, 600_000, 1_000_000, 2_000_000]

    for i, e in enumerate(energies):
        fpr = calibrated_reject_probs_model.predict_proba(X=pd.DataFrame({
            'c': c_grid,
            'null': np.repeat('negative', repeats=grid_size),
            'mu': np.repeat('negative', repeats=grid_size),
            'nu0': np.repeat(e, repeats=grid_size),
            'nu1': np.repeat(np.mean(calib_inputs.loc[:, 'nu1'].values), repeats=grid_size),
            'nu2': np.repeat(np.mean(calib_inputs.loc[:, 'nu2'].values), repeats=grid_size)
        }))[:, 1]
        tpr = calibrated_reject_probs_model.predict_proba(X=pd.DataFrame({
            'c': c_grid,
            'null': np.repeat('negative', repeats=grid_size),
            'mu': np.repeat('positive', repeats=grid_size),
            'nu0': np.repeat(e, repeats=grid_size),
            'nu1': np.repeat(np.mean(calib_inputs.loc[:, 'nu1'].values), repeats=grid_size),
            'nu2': np.repeat(np.mean(calib_inputs.loc[:, 'nu2'].values), repeats=grid_size)
        }))[:, 1]

        sns.lineplot(x=fpr, y=tpr, label=f'{e//1000} TeV', linestyle=linestyles[i], color=colors[i], linewidth=3, zorder=10)

    all_e_fpr, all_e_tpr, _ = roc_curve(
        y_true=calibration_set.is_gamma.values, 
        y_score=cat_gb.predict_proba(X=calibration_set.drop(columns=['energy', 'azimuth', 'zenith', 'is_gamma']).values)[:, 1]
    )
    sns.lineplot(x=all_e_fpr, y=all_e_tpr, label='Ignores nuisance', linestyle='-', color='red', linewidth=3, zorder=1)

    plt.xlabel('FPR', fontsize=20)
    plt.ylabel('TPR', fontsize=20)
    plt.tick_params(axis='both', which='major', labelsize=17)
    plt.legend(prop={'size': 15})
    plt.savefig('./results/figures/allNu_infCutoff/ROC.pdf', bbox_inches='tight')

    ## P-P plots
    X_calib, nu_calib, y_calib = calibration_set.drop(columns=['energy', 'azimuth', 'zenith', 'is_gamma']).values, calibration_set.loc[:, ['energy', 'azimuth', 'zenith',]].values, calibration_set.loc[:, 'is_gamma'].values
    bayes_factor = BayesFactor(
        poi_dim=1,
        estimator=cat_gb
    )
    bf_calib = bayes_factor.evaluate(samples=X_calib)
    bf_null0_calib_gamma, bf_null0_calib_hadron = bf_calib[y_calib == 1, 0], bf_calib[y_calib == 0, 0]
    bf_test = bayes_factor.evaluate(samples=X_test)
    emp_probs_gamma = np.array([(ts <= bf_null0_calib_gamma).sum()/bf_null0_calib_gamma.shape[0] for ts in bf_test[y_test == 1, 0]])
    emp_probs_hadron = np.array([(ts <= bf_null0_calib_hadron).sum()/bf_null0_calib_hadron.shape[0] for ts in bf_test[y_test == 0, 0]])

    blues = cm.Blues(np.linspace(0.35, 0.9, 4))
    reds = cm.Reds(np.linspace(0.35, 0.9, 4))
    bins = [1e5, 5*1e5, 1e6, 1.5*1e6, 1e7]

    fig, ax = plt.subplots(2, 1, figsize=(10, 10))

    legend_handles = []
    legend_labels = []
    for label in [0, 1]:
        for i, (low_nu, high_nu) in enumerate(zip(bins[:-1], bins[1:])):

            nu_y_mask = (nu_test[:, 0].reshape(-1, ) >= low_nu) & (nu_test[:, 0].reshape(-1, ) < high_nu) & (y_test == label)
            probs = calibrated_reject_probs_model.predict_proba(X=pd.DataFrame({
                'c': bf_test[nu_y_mask, 0],
                'null': np.repeat('negative', repeats=nu_y_mask.sum()),
                'mu': np.repeat('negative' if label == 0 else 'positive', repeats=nu_y_mask.sum()),
                'nu0': nu_test[:, 0].reshape(-1 )[nu_y_mask],
                'nu1': nu_test[:, 1].reshape(-1 )[nu_y_mask],
                'nu2': nu_test[:, 2].reshape(-1 )[nu_y_mask]
            }))[:, 1]
            
            (theoretical_quantiles, ordered_probs), (_, _, _) = stats.probplot(probs, dist=stats.uniform)
            plt_ours,  = ax[label].plot(theoretical_quantiles, ordered_probs, color=blues[i], linestyle='-', linewidth=7, zorder=10)

            # ignore nu
            nu_mask = (nu_test[:, 0].reshape(-1, )[y_test == label] >= low_nu) & (nu_test[:, 0].reshape(-1, )[y_test == label] < high_nu)
            if label == 1:
                plt_ign_nu,  = ax[label].plot(np.linspace(0, 1, len(emp_probs_gamma[nu_mask])), np.sort(emp_probs_gamma[nu_mask]), color=reds[i], linestyle='-', linewidth=7, zorder=1)
            else:
                plt_ign_nu,  = ax[label].plot(np.linspace(0, 1, len(emp_probs_hadron[nu_mask])), np.sort(emp_probs_hadron[nu_mask]), color=reds[i], linestyle='-', linewidth=7, zorder=1)

            if label == 0:
                legend_handles.append((plt_ign_nu, plt_ours))
                legend_labels.append(f'[{low_nu//1000:.0f}, {high_nu//1000:.0f}' + (']' if i == 3 else ')') + ' TeV')
        bisector, = ax[label].plot(np.linspace(0, 1, 1000), np.linspace(0, 1, 1000), linestyle='--', linewidth=7, color='black', label='Bisector', zorder=11)
        ax[1].set_xlabel('Uniform Quantiles', fontsize=30)
        ax[label].set_ylabel('Empirical Quantiles', fontsize=30)
        ax[label].set_title('Gamma' if label == 1 else 'Hadron', fontsize=32)
        ax[label].tick_params(axis='both', which='major', labelsize=20)

    ax[0].add_artist(
        ax[0].legend(
            [(bisector, ),tuple([el[1] for el in legend_handles]), tuple([el[0] for el in legend_handles])],
            ['Bisector', 'Nuisance-aware', 'Ignores nuisance'],
            loc='upper left', prop={'size': 23}, 
            handler_map={tuple: HandlerTuple(ndivide=None)}
        )
    )
    ax[0].legend(
        legend_handles, 
        legend_labels, 
        loc='lower right', prop={'size': 20}, 
        handler_map={tuple: HandlerTuple(ndivide=None)}
    )
    plt.tight_layout()
    plt.savefig('./results/figures/allNu_infCutoff/diagnostics_roc.pdf')

    ## baseline Bayes Clf; class proportions are equal for this example
    probs_test = cat_gb.predict_proba(X=X_test)[:, 1]
    preds_bayes_clf = np.hstack([(probs_test > 0.5).astype(int).reshape(y_test.shape[0], 1) for _ in range(len(alpha_grid))])
    results_df_bayesClf = pd.DataFrame({
        'true': y_test,
        **{f'clf_bayes_alpha{alpha_grid[i]:.3f}': preds_bayes_clf[:, i] for i in range(len(alpha_grid))}
    })

    ## within true label
    label = 1
    linewidth = 3.5
    markersize = 10
    fig, ax = plt.subplots(3, 2, figsize=(10, 9))
    bins = [1e5, 3e5, 1e7]
    for i, (nu_low, nu_high) in enumerate(zip(bins[:-1], bins[1:])):

        nu_y_masks = ((nu_test[:, 0].reshape(-1, ) >= nu_low) & (nu_test[:, 0].reshape(-1, ) < nu_high)) & (y_test == label)
        nu_y_masks_nacs = ((nu_test[:, 0].reshape(-1, ) >= nu_low) & (nu_test[:, 0].reshape(-1, ) < nu_high)) & (results_df_naps.true == label)

        # baseline Bayes classifier
        ax[0][i].plot(
            1-alpha_grid,
            [results_df_bayesClf.loc[(results_df_bayesClf.loc[:, col] == label) & nu_y_masks, :].shape[0] / results_df_bayesClf.loc[nu_y_masks, :].shape[0]
            for col in results_df_bayesClf.drop(columns='true').columns],
            linestyle='--', linewidth=linewidth+1, color='black', label='Bayes Clf'
        )
        ax[1][i].plot(
            1-alpha_grid,
            [results_df_bayesClf.loc[(results_df_bayesClf.loc[:, col] == (1-label)) & nu_y_masks, :].shape[0] / results_df_bayesClf.loc[nu_y_masks, :].shape[0]
            for col in results_df_bayesClf.drop(columns='true').columns],
            linestyle='--', linewidth=linewidth+1, color='black', label='Bayes Clf'
        )

        # ours, gamma=0
        ax[0][i].plot(
            1-alpha_grid,
            [results_df_conservative.loc[(results_df_conservative.loc[:, col] == label) & nu_y_masks, :].shape[0] / results_df_conservative.loc[nu_y_masks, :].shape[0]
            for col in results_df_conservative.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='o', markersize=markersize, color='cornflowerblue', label=r'NAPS $\gamma=0$ (Ours)'
        )
        ax[1][i].plot(
            1-alpha_grid,
            [results_df_conservative.loc[(results_df_conservative.loc[:, col] == (1-label)) & nu_y_masks, :].shape[0] / results_df_conservative.loc[nu_y_masks, :].shape[0]
            for col in results_df_conservative.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='o', markersize=markersize, color='cornflowerblue', label=r'NAPS $\gamma=0$ (Ours)'
        )
        ax[2][i].plot(
            1-alpha_grid,
            [results_df_conservative.loc[(results_df_conservative.loc[:, col] == -1) & nu_y_masks, :].shape[0] / results_df_conservative.loc[nu_y_masks, :].shape[0]
            for col in results_df_conservative.drop(columns='true').columns],
            linestyle=':', linewidth=linewidth, marker='o', markersize=markersize, color='cornflowerblue', label=r'$\{0, 1\}$, NAPS $\gamma=0$'
        )
        ax[2][i].plot(
            1-alpha_grid,
            [results_df_conservative.loc[(results_df_conservative.loc[:, col] == -2) & nu_y_masks, :].shape[0] / results_df_conservative.loc[nu_y_masks, :].shape[0]
            for col in results_df_conservative.drop(columns='true').columns],
            linestyle='--', linewidth=linewidth, marker='o', markersize=markersize, color='cornflowerblue', label=r'$\emptyset$, NAPS $\gamma=0$'
        )

        # ours, gamma>0
        ax[0][i].plot(
            1-alpha_grid,
            [results_df_naps.loc[(results_df_naps.loc[:, col] == label) & (nu_y_masks_nacs), :].shape[0] / results_df_naps.loc[nu_y_masks_nacs, :].shape[0]
            for col in results_df_naps.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='*', markersize=markersize+4, color='limegreen', label=r'NAPS $\gamma>0$ (Ours)'
        )
        ax[1][i].plot(
            1-alpha_grid,
            [results_df_naps.loc[(results_df_naps.loc[:, col] == (1-label)) & (nu_y_masks_nacs), :].shape[0] / results_df_naps.loc[nu_y_masks_nacs, :].shape[0]
            for col in results_df_naps.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='*', markersize=markersize+4, color='limegreen', label=r'NAPS $\gamma>0$ (Ours)'
        )
        ax[2][i].plot(
            1-alpha_grid,
            [results_df_naps.loc[(results_df_naps.loc[:, col] == -1) & (nu_y_masks_nacs), :].shape[0] / results_df_naps.loc[nu_y_masks_nacs, :].shape[0]
            for col in results_df_naps.drop(columns='true').columns],
            linestyle=':', linewidth=linewidth, marker='*', markersize=markersize+4, color='limegreen', label=r'$\{0, 1\}$, NAPS $\gamma>0$'
        )
        ax[2][i].plot(
            1-alpha_grid,
            [results_df_naps.loc[(results_df_naps.loc[:, col] == -2) & (nu_y_masks_nacs), :].shape[0] / results_df_naps.loc[nu_y_masks_nacs, :].shape[0]
            for col in results_df_naps.drop(columns='true').columns],
            linestyle='--', linewidth=linewidth, marker='*', markersize=markersize+4, color='limegreen', label=r'$\emptyset$, NAPS $\gamma>0$'
        )

        ax[0][i].set_ylim(-0.05, 1.05)
        ax[1][i].set_ylim(-0.05, 1.05)
        ax[2][i].set_ylim(-0.05, 1.05)
        ax[0][i].tick_params(axis='both', which='major', labelsize=15)
        ax[1][i].tick_params(axis='both', which='major', labelsize=15)
        ax[2][i].tick_params(axis='both', which='major', labelsize=15)
        if i != 0:
            ax[0][i].tick_params(labelleft=False)
            ax[1][i].tick_params(labelleft=False)
            ax[2][i].tick_params(labelleft=False)
        ax[0][i].tick_params(labelbottom=False)
        ax[1][i].tick_params(labelbottom=False)

        # ax[2][i].set_xlabel(r'Confidence Level $(1-\alpha)$', fontsize=20)
        ax[0][0].set_ylabel("TPR (or Recall)" if label == 1 else "TNR (or Specificity)", fontsize=20)
        ax[1][0].set_ylabel("FNR (or Miss Rate)" if label == 1 else "FPR", fontsize=20)
        ax[2][0].set_ylabel("Ambiguous", fontsize=20)

        #plt.figtext([0.2, 0.5, 0.8][i], 0.97, f'Energy: [{nu_low//1000:.0f}, {nu_high//1000:.0f}' + (']' if i == 2 else ')') + ' TeV', ha=["left", "center", "right"][i], va="top", fontsize=15)

    # frames
    #for a in ax:
    #    a.patch.set_linewidth(5)
    #    a.patch.set_edgecolor('k')
        
    fig.patches.append(patches.Rectangle((0.001, 0.68), 0.99, 0.315, transform=fig.transFigure, edgecolor='black', linewidth=2, facecolor="gainsboro", zorder=-1))
    fig.patches.append(patches.Rectangle((0.001, 0.356), 0.99, 0.315, transform=fig.transFigure, edgecolor='black', linewidth=2, facecolor="gainsboro", zorder=-1))
    fig.patches.append(patches.Rectangle((0.001, 0.013), 0.99, 0.335, transform=fig.transFigure, edgecolor='black', linewidth=2, facecolor="gainsboro", zorder=-1))

    # just for the legend
    #ax[2][2].plot(0.6, 0.6, linestyle=':', linewidth=3, label=r'$\{0, 1\}$, NAPS Clf', color='grey')
    #ax[2][2].plot(0.6, 0.6, linestyle='--', linewidth=3, label=r'$\emptyset$, NAPS Clf', color='grey')

    plt.figtext(-0.04, 0.28, r'Within True {label} ($y_{{true}} = {labelnum}$)'.format(label=('Gamma' if label == 1 else 'Hadron'), labelnum=label), fontsize=20, rotation=90, fontweight=777)

    #for j in range(3):
    #    ax[j][0].set_ylabel('Proportions', fontsize=20)
    ax[0][1].legend(loc='lower left', prop={'size': 15})
    ax[2][1].legend(loc='upper left', prop={'size': 15})
    #plt.subplots_adjust(hspace = 1)
    plt.tight_layout(h_pad=2)
    plt.savefig(f'./results/figures/allNu_bergerCutoff/within{"_gamma" if label == 1 else "_hadron"}.pdf', bbox_inches='tight')


    ## within predicted label
    label = 1
    linewidth = 3.5
    markersize = 10
    fig, ax = plt.subplots(2, 2, figsize=(10, 6))
    bins = [1e5, 3e5, 1e7]

    for i, (nu_low, nu_high) in enumerate(zip(bins[:-1], bins[1:])):

        nu_y_pred_masks = lambda df, c: (([nu_test][:, 0].reshape(-1, ) >= nu_low) & (nu_test[:, 0].reshape(-1, ) < nu_high)) & (df.loc[:, c] == label)
        nu_y_pred_masks_nacs = lambda df, c: ((nu_test[:, 0].reshape(-1, ) >= nu_low) & (nu_test[:, 0].reshape(-1, ) < nu_high)) & (df.loc[:, c] == label)

        # baseline Bayes classifier
        ax[0][i].plot(
            1-alpha_grid,
            [results_df_bayesClf.loc[(y_test == label) & nu_y_pred_masks(results_df_bayesClf, col), :].shape[0] / results_df_bayesClf.loc[nu_y_pred_masks(results_df_bayesClf, col), :].shape[0]
            for col in results_df_bayesClf.drop(columns='true').columns],
            linestyle='--', linewidth=linewidth+1, color='black', label='Bayes Clf'
        )
        ax[1][i].plot(
            1-alpha_grid,
            [results_df_bayesClf.loc[(y_test == (1-label)) & nu_y_pred_masks(results_df_bayesClf, col), :].shape[0] / results_df_bayesClf.loc[nu_y_pred_masks(results_df_bayesClf, col), :].shape[0]
            for col in results_df_bayesClf.drop(columns='true').columns],
            linestyle='--', linewidth=linewidth+1, color='black', label='Bayes Clf'
        )

        # ours, gamma=0
        ax[0][i].plot(
            1-alpha_grid,
            [results_df_conservative.loc[(y_test == label) & nu_y_pred_masks(results_df_conservative, col), :].shape[0] / results_df_conservative.loc[nu_y_pred_masks(results_df_conservative, col), :].shape[0]
            for col in results_df_conservative.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='o', markersize=markersize, color='cornflowerblue', label=r'NAPS $\gamma=0$ (Ours)'
        )
        ax[1][i].plot(
            1-alpha_grid,
            [results_df_conservative.loc[(y_test == (1-label)) & nu_y_pred_masks(results_df_conservative, col), :].shape[0] / results_df_conservative.loc[nu_y_pred_masks(results_df_conservative, col), :].shape[0]
            for col in results_df_conservative.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='o', markersize=markersize, color='cornflowerblue', label=r'NAPS $\gamma=0$ (Ours)'
        )

        # ours, gamma>0
        ax[0][i].plot(
            1-alpha_grid,
            [results_df_naps.loc[(results_df_naps.loc[:, 'true'] == label) & nu_y_pred_masks_nacs(results_df_naps, col), :].shape[0] / results_df_naps.loc[nu_y_pred_masks_nacs(results_df_naps, col), :].shape[0]
            for col in results_df_naps.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='*', markersize=markersize+4, color='limegreen', label=r'NAPS $\gamma>0$ (Ours)'
        )
        ax[1][i].plot(
            1-alpha_grid,
            [results_df_naps.loc[(results_df_naps.loc[:, 'true'] == (1-label)) & nu_y_pred_masks_nacs(results_df_naps, col), :].shape[0] / results_df_naps.loc[nu_y_pred_masks_nacs(results_df_naps, col), :].shape[0]
            for col in results_df_naps.drop(columns='true').columns],
            linestyle='-', linewidth=linewidth, marker='*', markersize=markersize+4, color='limegreen', label=r'NAPS $\gamma>0$ (Ours)'
        )

        ax[0][i].set_ylim(-0.05, 1.05)
        ax[1][i].set_ylim(-0.05, 1.05)
        ax[0][i].tick_params(axis='both', which='major', labelsize=15)
        ax[1][i].tick_params(axis='both', which='major', labelsize=15)
        if i != 0:
            ax[0][i].tick_params(labelleft=False)
            ax[1][i].tick_params(labelleft=False)
        ax[0][i].tick_params(labelbottom=False)

        #ax[1][i].set_xlabel(r'Nominal Coverage $(1-\alpha)$', fontsize=20)
        ax[0][0].set_ylabel("Precision" if label == 1 else "Negative Predictive Value", fontsize=20)
        ax[1][0].set_ylabel("FDR" if label == 1 else "False Omission Rate", fontsize=20)

    fig.patches.append(patches.Rectangle((0.015, 0.527), 0.975, 0.462, transform=fig.transFigure, edgecolor='black', linewidth=2, facecolor="ivory", zorder=-1))
    fig.patches.append(patches.Rectangle((0.015, 0.013), 0.975, 0.5, transform=fig.transFigure, edgecolor='black', linewidth=2, facecolor="ivory", zorder=-1))

    plt.figtext(-0.04, 0.08, r'Within Predicted {label} ($y_{{pred}} = {labelnum}$)'.format(label=('Gamma' if label == 1 else 'Hadron'), labelnum=label), fontsize=20, rotation=90, fontweight=777)

    #for j in range(2):
    #    ax[j][0].set_ylabel('Proportions', fontsize=20)
    ax[0][1].legend(loc='lower left', prop={'size': 15})

    #plt.figtext(0.5,0.97, f'Energy: [{nu_low//1000:.0f}, {nu_high//1000:.0f}' + (']' if i == 2 else ')') + ' TeV', ha="center", va="top", fontsize=15)
    #plt.subplots_adjust(hspace = 0.3)
    plt.tight_layout(h_pad=2)
    plt.savefig(f'./results/figures/allNu_bergerCutoff/within_predicted{"_gamma" if label == 1 else "_hadron"}.pdf', bbox_inches='tight')


if __name__ == '__main__':
    main()
