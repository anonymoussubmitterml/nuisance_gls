import sys
sys.path.append('..')
from tqdm import tqdm
import pickle
from joblib import Parallel, delayed
import click

import numpy as np
import pandas as pd
from sklearn.model_selection import RandomizedSearchCV
from sklearn.calibration import CalibratedClassifierCV
from catboost import CatBoostClassifier
from sbi.simulators.simutils import tqdm_joblib
import torch
from sbi.utils import BoxUniform

from common.test_statistic import BayesFactor, ClfProb
from common.calibration import prepare_calibration_set, estimate_rejection_probs, optimal_cutoffs
from common.utils import select_n_jobs
from lf2i.confidence_regions.neyman_inversion import compute_confidence_regions
from lf2i.inference import LF2I


@click.group()
def main():
    pass


@main.command()
def run():

    ###### DATA
    with open('./data/all_events.pkl', 'rb') as f:
        data = pickle.load(f)

    train_set = data.loc[data.split_id == 0, :].drop(columns='split_id').sample(frac=1).reset_index(drop=True)
    calibration_set = data.loc[data.split_id == 1, :].drop(columns='split_id').sample(frac=1).reset_index(drop=True)
    test_set = data.loc[data.split_id == 2, :].drop(columns='split_id').sample(frac=1).reset_index(drop=True)

    with open('./data/split_data.pkl', 'wb') as f:
        pickle.dump({'train_set': train_set, 'calibration_set': calibration_set, 'test_set': test_set}, f)

    ###### TRAIN BASE CLASSIFIER
    X_train, y_train = train_set.drop(columns=['energy', 'zenith', 'azimuth', 'is_gamma']).values, train_set.loc[:, 'is_gamma'].values
    cat_gb = RandomizedSearchCV(
        estimator=CatBoostClassifier(
            loss_function='CrossEntropy',
            silent=True
        ),
        param_distributions={'iterations': [100, 300, 500, 700, 1000], 'depth': [1, 3, 5, 7, 10]},
        n_iter=25,
        n_jobs=select_n_jobs(10),
        refit=True,
        cv=5,
        verbose=1
    )
    cat_gb.fit(X=X_train, y=y_train)
    with open('./results/pickles/allNu_infCutoff/catgb_clf.pkl', 'wb') as f:
        pickle.dump(cat_gb, f)

    bayes_factor = BayesFactor(
        poi_dim=1,
        estimator=cat_gb
    )

    ###### ESTIMATE REJECTION PROBABILITY
    X_calib, nu_calib, y_calib = calibration_set.drop(columns=['energy', 'zenith', 'azimuth', 'is_gamma']).values, calibration_set.loc[:, ['energy', 'zenith', 'azimuth']].values, calibration_set.loc[:, 'is_gamma'].values
    bf_calib = bayes_factor.evaluate(samples=X_calib)

    calib_inputs, rejection_indicators = prepare_calibration_set(
        test_statistics=bf_calib,
        poi=y_calib,
        nuisance=nu_calib,
        control='power',
        cutoff_sampling='empirical-cdf',
        num_cutoffs=50,
        shuffle=True,
        return_pd=True
    )
    with open('./data/augment_calib_data.pkl', 'wb') as f:
        pickle.dump({'calib_inputs': calib_inputs, 'rejection_indicators': rejection_indicators}, f)

    reject_probs_model = estimate_rejection_probs(
        inputs=calib_inputs,
        rejection_indicators=rejection_indicators,
        method='gb',
        hyperparams={'iterations': [100, 300, 500, 700, 1000], 'depth': [1, 3, 5, 7, 10]},
        n_jobs=20,
        cat_features_idxs=[1, 2],
        n_iter=25
    )

    calibrated_reject_probs_model = CalibratedClassifierCV(
        estimator=CatBoostClassifier(
            loss_function='CrossEntropy',
            iterations=reject_probs_model.best_params_['iterations'],
            depth=reject_probs_model.best_params_['depth'],
            silent=True,
            monotone_constraints="0:1",  # 1 means non-decreasing function of cutoffs (always 1st column of inputs, 0 index),
            cat_features=[1, 2]
        ),
        method='isotonic',
        cv=5,
        n_jobs=20
    )
    calibrated_reject_probs_model.fit(X=calib_inputs, y=rejection_indicators)
    with open('./results/pickles/allNu_infCutoff/calibrated_reject_probs_model.pkl', 'wb') as f:
        pickle.dump(calibrated_reject_probs_model, f)

    ###### PREDICTIONS SETS, NAPS GAMMA=0
    X_test, nu_test, y_test = test_set.drop(columns=['energy', 'zenith', 'azimuth', 'is_gamma']).values, test_set.loc[:, ['energy', 'zenith', 'azimuth']].values, test_set.loc[:, 'is_gamma'].values
    alpha_grid = np.array([0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15, 0.1, 0.05, 0.01])

    def do_one(alpha_value):
        opt_c = optimal_cutoffs(
            alpha=alpha_value,
            rejection_probs_model=calibrated_reject_probs_model,
            cutoffs_bounds=[(-11, 11), (-11, 11)],
            control='power',
            nuisance_bounds=[[1e5, 1e7], [0, np.pi/2], [-np.pi, np.pi]],
            opt_method='diff-evol',
            max_range_expand=100,
            popsize=30,
            verbose=True
        )
        return opt_c, compute_confidence_regions(
            test_statistic=bayes_factor.evaluate(samples=X_test),
            critical_values=opt_c,
            parameter_grid=np.array([0, 1]),
            acceptance_region=bayes_factor.acceptance_region,
            poi_dim=bayes_factor.poi_dim
        )
    with tqdm_joblib(tqdm(alpha_grid, total=len(alpha_grid))) as _:
        opt_cutoffs, prediction_sets = tuple(zip(*Parallel(n_jobs=-2)(delayed(do_one)(alpha) for alpha in alpha_grid)))

    set_clf_outputs = []
    for idx_alpha, cs_at_alpha in tqdm(enumerate(prediction_sets)):
        # 0, 1, -1 (both), -2 (empty)
        set_clf_outputs_alpha = []
        for idx, cs in enumerate(cs_at_alpha):
            cs = cs.reshape(-1 )
            if len(cs) == 0:
                set_clf_outputs_alpha.append(-2)
            elif len(cs) == 1:
                set_clf_outputs_alpha.append(cs.item())
            elif len(cs) == 2:
                set_clf_outputs_alpha.append(-1)
            else:
                print(cs, flush=True)
                raise ValueError("There's something wrong")
        set_clf_outputs.append(set_clf_outputs_alpha)
    d = {'true': y_test}
    d.update({f'setClf_alpha{alpha_grid[i]:.3f}': o for i, o in enumerate(set_clf_outputs)})
    results_df = pd.DataFrame(d)

    with open('./results/pickles/allNu_infCutoff/setClf_alpha.pkl', 'wb') as f:
        pickle.dump(results_df, f)

    ###### PREDICTION SETS, NAPS GAMMA>0
    
    ### TRAIN LF2I TO GET CONFIDENCE SETS ON NU
    with open('./data/split_data.pkl', 'rb') as f:
        d = pickle.load(f)
        train_set, calibration_set, test_set = d['train_set'], d['calibration_set'], d['test_set']
    gamma_grid = alpha_grid * 0.3
    evaluation_grid = BoxUniform(low=torch.Tensor([100_000, 0, -np.pi]), high=torch.Tensor([10_000_000, np.pi/2, np.pi])).sample(sample_shape=(100_000, ))
    
    # GAMMA
    train_set = train_set.loc[train_set.is_gamma == 1, :].drop(columns=['is_gamma'])
    calibration_set = calibration_set.loc[calibration_set.is_gamma == 1, :].drop(columns=['is_gamma'])
    test_set = test_set.loc[test_set.is_gamma == 1, :].drop(columns=['is_gamma'])
    X_train, nu_train = torch.from_numpy(train_set.drop(columns=['energy', 'zenith', 'azimuth']).values), torch.from_numpy(train_set.loc[:, ['energy', 'zenith', 'azimuth']].values)
    X_calib, nu_calib = torch.from_numpy(calibration_set.drop(columns=['energy', 'zenith', 'azimuth']).values), torch.from_numpy(calibration_set.loc[:, ['energy', 'zenith', 'azimuth']].values)
    X_test, nu_test = torch.from_numpy(test_set.drop(columns=['energy', 'zenith', 'azimuth']).values), torch.from_numpy(test_set.loc[:, ['energy', 'zenith', 'azimuth']].values)
    lf2i = LF2I(
        test_statistic='waldo',
        estimator='snpe',
        poi_dim=3,
        estimation_method='posterior',
        num_posterior_samples=50_000,
        estimator_kwargs={'density_estimator': 'maf'},
        n_jobs=-2
    )
    for gamma in gamma_grid:
        confidence_sets = lf2i.inference(
            x=X_test[0, :],  # just a placeholder. Goal here is only to estimate SNPE and QR
            evaluation_grid = evaluation_grid.numpy(),
            confidence_level=np.round(1-gamma, decimals=3),
            T=(nu_train.float(), X_train.float()),
            T_prime=(nu_calib.float(), X_calib.float()),
            verbose=True
        )
    with open('./results/pickles/allNu_bergerCutoff/waldo_gamma.pkl', 'wb') as f:
        pickle.dump(lf2i, f)
    
    # HADRON
    train_set = train_set.loc[train_set.is_gamma == 0, :].drop(columns=['is_gamma'])
    calibration_set = calibration_set.loc[calibration_set.is_gamma == 0, :].drop(columns=['is_gamma'])
    test_set = test_set.loc[test_set.is_gamma == 0, :].drop(columns=['is_gamma'])
    X_train, nu_train = torch.from_numpy(train_set.drop(columns=['energy', 'zenith', 'azimuth']).values), torch.from_numpy(train_set.loc[:, ['energy', 'zenith', 'azimuth']].values)
    X_calib, nu_calib = torch.from_numpy(calibration_set.drop(columns=['energy', 'zenith', 'azimuth']).values), torch.from_numpy(calibration_set.loc[:, ['energy', 'zenith', 'azimuth']].values)
    X_test, nu_test = torch.from_numpy(test_set.drop(columns=['energy', 'zenith', 'azimuth']).values), torch.from_numpy(test_set.loc[:, ['energy', 'zenith', 'azimuth']].values)
    lf2i = LF2I(
        test_statistic='waldo',
        estimator='snpe',
        poi_dim=3,
        estimation_method='posterior',
        num_posterior_samples=50_000,
        estimator_kwargs={'density_estimator': 'maf'},
        n_jobs=-2
    )
    for gamma in gamma_grid:
        confidence_sets = lf2i.inference(
            x=X_test[0, :],  # just a placeholder. Goal here is only to estimate SNPE and QR
            evaluation_grid = evaluation_grid.numpy(),
            confidence_level=np.round(1-gamma, decimals=3),
            T=(nu_train.float(), X_train.float()),
            T_prime=(nu_calib.float(), X_calib.float()),
            verbose=True
        )
    with open('./results/pickles/allNu_bergerCutoff/waldo_hadron.pkl', 'wb') as f:
        pickle.dump(lf2i, f)

    ### GET PREDICTION SETS
    with open('./data/split_data.pkl', 'rb') as f:
        d = pickle.load(f)
        train_set, calibration_set, test_set = d['train_set'], d['calibration_set'], d['test_set']
    def lf2i_cs(confidence_level, eval_grid, verbose):
        with open('./results/pickles/allNu_bergerCutoff/waldo_hadron.pkl', 'rb') as f:
            waldo_hadron = pickle.load(f)
        with open('./results/pickles/allNu_bergerCutoff/waldo_gamma.pkl', 'rb') as f:
            waldo_gamma = pickle.load(f)
        
        def get_cs(x, null):
            if null == 0:
                return waldo_hadron.inference(x=x, evaluation_grid=eval_grid, confidence_level=confidence_level, verbose=verbose)[0]
            elif null == 1:
                return waldo_gamma.inference(x=x, evaluation_grid=eval_grid, confidence_level=confidence_level, verbose=verbose)[0]
            else:
                raise ValueError(f'null equals {null}')
        return get_cs
    
    min_c, max_c = calib_inputs.agg(['min', 'max']).loc[:, 'c'].values
    def do_one(alpha_value, gamma_value):
        return optimal_cutoffs(
            alpha=alpha_value,
            rejection_probs_model=calibrated_reject_probs_model,
            cutoffs_bounds=[(min_c, max_c), (min_c, max_c)],
            control='power',
            x_obs=torch.from_numpy(X_test),
            nuisance_cs=lf2i_cs(confidence_level=np.round(1-gamma_value, decimals=3), eval_grid=evaluation_grid, verbose=False),
            gamma=gamma_value,
            nuisance_bounds=[[1e5, 1e7], [0, np.pi/2], [-np.pi, np.pi]],  # only used if a nuisance cs is empty
            opt_method='approx-cs/diff-evol',
            max_range_expand=100,
            verbose=False,
            n_jobs=-2,
            popsize=30,
            # mutation=(0.5, 1.9)
        )
    opt_cutoffs = [do_one(alpha, gamma) for alpha, gamma in list(zip(alpha_grid, gamma_grid))]
    bf_test = bayes_factor.evaluate(samples=X_test)

    prediction_sets = []
    for i in tqdm(range(len(alpha_grid))):
        prediction_sets.append(
            [np.array([0, 1])[bf_test[j, :] >= opt_cutoffs[i][j, :]] for j in range(len(bf_test))]
        )
    set_clf_outputs = []
    for idx_alpha, cs_at_alpha in tqdm(enumerate(prediction_sets)):
        # 0, 1, -1 (both), -2 (empty)
        set_clf_outputs_alpha = []
        for idx, cs in enumerate(cs_at_alpha):
            cs = cs.reshape(-1 )
            if len(cs) == 0:
                set_clf_outputs_alpha.append(-2)
            elif len(cs) == 1:
                set_clf_outputs_alpha.append(cs.item())
            elif len(cs) == 2:
                set_clf_outputs_alpha.append(-1)
            else:
                print(cs, flush=True)
                raise ValueError("There's something wrong")
        set_clf_outputs.append(set_clf_outputs_alpha)
    d = {'true': y_test}
    d.update({f'setClf_alpha{alpha_grid[i]:.2f}': o for i, o in enumerate(set_clf_outputs)})
    results_df = pd.DataFrame(d)

    with open('./results/pickles/allNu_bergerCutoff/setClf_alpha.pkl', 'wb') as f:
        pickle.dump(results_df, f)


if __name__ == '__main__':
    main()
