from typing import Tuple, Optional, Callable, Sequence, List, Any, Union, Dict
from tqdm import tqdm
from joblib import Parallel, delayed
from sbi.simulators.simutils import tqdm_joblib

import math
import numpy as np
import pandas as pd
import torch
from scipy.optimize import minimize, brentq, differential_evolution
from catboost import CatBoostClassifier
from sklearn.model_selection import RandomizedSearchCV
from .utils import fit_kde, select_n_jobs
from lf2i.utils.miscellanea import check_for_nans


def prepare_calibration_set(
    test_statistics: np.ndarray,
    poi: np.ndarray,
    nuisance: np.ndarray,  # TODO: check things in the case we have both continuous and discrete nuisances
    control: str = 'all',  # fpr, tpr, power, all ...
    cutoff_sampling: str = 'empirical-cdf',   # empirical-cdf, kde, ...?
    num_cutoffs: int = 1000,
    shuffle: bool = True,
    kde_kwargs: Optional[Dict[str, Any]] = None,
    return_pd: bool = True
) -> Union[Tuple[pd.DataFrame, pd.Series], Tuple[np.ndarray]]:
    assert len(np.unique(poi)) == 2, "Only implemented for binary classification at the moment"

    if poi.ndim > 1:
        poi = poi.reshape(-1, )
    if nuisance.ndim == 1:
        nuisance = np.expand_dims(nuisance, axis=1)

    if cutoff_sampling == 'kde':
        print('Fitting kde ...', flush=True)
        # fit a kde to the test statistics evaluated at mu_0 = 0, 1, 2, ... for all classes
        cutoff_distr = [(lambda size: fit_kde(X=test_statistics[:, i], **kde_kwargs)(size)) for i in range(test_statistics.shape[1])]
        print('Done!', flush=True)
    elif cutoff_sampling == 'empirical-cdf':
        cutoff_distr = [(lambda size: np.random.choice(a=test_statistics[:, i], size=size, replace=True)) for i in range(test_statistics.shape[1])]
    else:
        # TODO: implement cutoff grid and cutoff distribution. Can use iterator to have similar data structure to kde output
        raise NotImplementedError
    
    # augment data by sampling cutoffs
    num_true_0, num_true_1 = (poi == 0).sum(), (poi == 1).sum()
    cutoffs_null0_first = cutoff_distr[0](num_cutoffs*num_true_0).reshape(num_true_0, num_cutoffs)  # for power with null = 0
    cutoffs_null0_second = cutoff_distr[0](num_cutoffs*num_true_1).reshape(num_true_1, num_cutoffs) # for tpr
    cutoffs_null1 = cutoff_distr[1](num_cutoffs*num_true_1).reshape(num_true_1, num_cutoffs) # for power with null = 1
    
    # need to estimate FPR (null = 0, true_mu = 0), TPR (null = 0, true_mu = 1) and POWER ((null = 0, true_mu = 0) and (null = 1, true_mu = 1))
    # POWER partially overlaps with FPR, hence need three cases only
    null = np.repeat(np.array(['negative']*num_true_0 + ['negative']*num_true_1 + ['positive']*num_true_1), repeats=num_cutoffs)
    mu = np.repeat(np.array(['negative']*num_true_0 + ['positive']*num_true_1 + ['positive']*num_true_1), repeats=num_cutoffs)
    nu = np.repeat(np.concatenate((nuisance[poi == 0, :], nuisance[poi == 1, :], nuisance[poi == 1, :])), repeats=num_cutoffs, axis=0)
    cutoffs = np.vstack((cutoffs_null0_first, cutoffs_null0_second, cutoffs_null1)).reshape(-1, )
    rejection_indicators = np.concatenate((
        (test_statistics[poi == 0, 0].reshape(-1, 1) < cutoffs_null0_first).astype(int).reshape(-1, ),
        (test_statistics[poi == 1, 0].reshape(-1, 1) < cutoffs_null0_second).astype(int).reshape(-1, ),
        (test_statistics[poi == 1, 1].reshape(-1, 1) < cutoffs_null1).astype(int).reshape(-1, )
    ))
    assert mu.shape[0] == nu.shape[0] == rejection_indicators.shape[0] == (num_true_0*num_cutoffs + num_true_1*num_cutoffs*2)

    # control == 'all' just returns all three combinations
    if control == 'power':
        mask0, mask1 = (null == 'negative') & (mu == 'negative'), (null == 'positive') & (mu == 'positive')
        null, mu, nu = null[mask0 | mask1], mu[mask0 | mask1], nu[mask0 | mask1, :]
        cutoffs, rejection_indicators = cutoffs[mask0 | mask1], rejection_indicators[mask0 | mask1]
    elif control == 'fpr':
        raise NotImplementedError
    elif control == 'tpr':
        raise NotImplementedError
    
    if shuffle:
        shuffled_idx = np.random.choice(range(l:=len(rejection_indicators)), size=l, replace=False)
        null, mu, nu = null[shuffled_idx], mu[shuffled_idx], nu[shuffled_idx, :]
        cutoffs, rejection_indicators = cutoffs[shuffled_idx], rejection_indicators[shuffled_idx]
    if return_pd:
        inputs = pd.DataFrame(
            data={'c': cutoffs.astype(float), 'null': null, 'mu': mu, **{f'nu{i}': nu[:, i] for i in range(nu.shape[1])}}
        )
        return inputs, pd.Series(rejection_indicators)
    else:
        return null, mu, nu, cutoffs, rejection_indicators
    

def estimate_rejection_probs(
    inputs: Union[np.ndarray, torch.Tensor, pd.DataFrame], 
    rejection_indicators: Union[np.ndarray, torch.Tensor, pd.Series], 
    method: str,
    hyperparams: Optional[Dict[str, Any]] = None,
    cat_features_idxs: Optional[List[int]] = None,
    n_iter: int = 20,
    n_folds: int = 5,
    n_jobs: int = -2
) -> Any:
    if method == 'gb':
        n_jobs = select_n_jobs(n_jobs)
        hyperparams = hyperparams or {'iterations': [100, 300, 500, 700, 1000], 'depth': [1, 3, 5, 7, 10]}
        algorithm = RandomizedSearchCV(
            estimator=CatBoostClassifier(
                loss_function='CrossEntropy',
                silent=True,
                monotone_constraints="0:1",  # 1 means non-decreasing function of cutoffs (always 1st column of inputs, 0 index),
            ),
            param_distributions=hyperparams,
            n_iter=n_iter,
            n_jobs=n_jobs,
            refit=True,
            cv=n_folds,
            verbose=1
        )
        inputs, rejection_indicators = preprocess_fit_predict(inputs, algorithm), preprocess_fit_predict(rejection_indicators, algorithm)
        algorithm.fit(
            X=inputs, 
            y=rejection_indicators.reshape(-1, ) if isinstance(rejection_indicators, (torch.Tensor, np.ndarray)) else rejection_indicators, 
            cat_features=cat_features_idxs
        )
    elif method == 'splines':
        raise NotImplementedError
    elif method == 'nn':
        raise NotImplementedError
    else:
        raise ValueError
    return algorithm


def preprocess_fit_predict(
    inputs: Union[np.ndarray, torch.Tensor],
    rejection_probs_model: Any
) -> Union[np.ndarray, torch.Tensor]:
    check_for_nans(inputs)
    if isinstance(rejection_probs_model, torch.nn.Module) or (hasattr(rejection_probs_model, 'model') and isinstance(rejection_probs_model.model, torch.nn.Module)):
        # PyTorch models
        if isinstance(inputs, np.ndarray):
            inputs = torch.from_numpy(inputs)
        if inputs.ndim == 1:
            inputs = inputs.unsqueeze(1)
    else:  # assume anything else works with numpy arrays (or pandas; do not check for that)
        # Scikit-Learn, XGBoost, CatBoost, etc...
        if isinstance(inputs, torch.Tensor):
            inputs = inputs.numpy()
        if inputs.ndim == 1:
            inputs = np.expand_dims(inputs, axis=1)
    return inputs
        

def inverse_control_fun(
    rejection_probs_model: Any,  # any model that implements predict_proba(X=...) method
    beta: float,  # alpha - gamma
    null: str,
    mu: str,
    nu: np.ndarray,
    cutoffs_bounds: Tuple[float],
    max_range_expand: int,
    verbose: bool,
    brute_force_grid_size: int = 100_000
) -> float:
    """Approximate inverse of FPR/TPR/POWER via brentq root finding method"""
    assert max_range_expand >= 1, f"Brackets expansion factor must be greater than 1 otherwise will immediately default to brute force root finding, got {max_range_expand}"

    rej_prob = lambda c: rejection_probs_model.predict_proba(X=pd.DataFrame({
        'c': np.array([c]), 'null': np.array([null]), 'mu': np.array([mu]), **{f'nu{i}': nu[i] for i in range(len(nu))}
    }))[:, 1]
    # expand brackets until f(a) and f(b) have opposite signs, if possible ...
    low, high = cutoffs_bounds[0], cutoffs_bounds[1]
    expand = 0.1 * (high-low)  # heuristic: expand by 10% at every iter until `max_range_expand` times the initial range
    while (high-low < max_range_expand*(cutoffs_bounds[1]-cutoffs_bounds[0])) or math.isclose(high-low, max_range_expand*(cutoffs_bounds[1]-cutoffs_bounds[0])):
        try:
            root = brentq(
                f=lambda c: rej_prob(c) - beta,
                a=low,
                b=high
            )
            if (low < cutoffs_bounds[0]) and (high > cutoffs_bounds[1]) and verbose:
                print(f'Found root with low: {low:.2f}, high: {high:.2f}', flush=True)
            return root
        except ValueError as e:
            #if verbose:
            #    print(str(e), flush=True)
            low, high = low-expand, high+expand
            # print(low, high, flush=True)
            continue

    # ... otherwise, just find the approximate root by brute force
    if verbose:
        print(f'Raised: ValueError even with expanded brackets. Switching to brute-force evaluations for root finding in this instance', flush=True)
    cutoff_grid = np.linspace(low, high, brute_force_grid_size)  # use expanded brackets
    rej_prob = rejection_probs_model.predict_proba(X=pd.DataFrame({
        'c': cutoff_grid, 'null': np.repeat(null, repeats=brute_force_grid_size), 'mu': np.repeat(mu, repeats=brute_force_grid_size), 
        **{f'nu{i}': np.repeat(nu[i], repeats=brute_force_grid_size, axis=0) for i in range(len(nu))}
    }))[:, 1]
    root = cutoff_grid[np.argmin(tol:=np.abs(rej_prob - beta))]
    if verbose:
        print(f'Actual tol: {np.min(tol)}', flush=True)
    return root
    

def optimal_cutoffs(
    alpha: float,
    rejection_probs_model: Any,  # any model that implements predict_proba(X=...) method
    cutoffs_bounds: List[Tuple[float]],
    control: str,  # fpr, tpr, power, ...
    x_obs: Optional[Union[np.ndarray, torch.Tensor]] = None,
    nuisance_cs: Optional[Union[Sequence[Sequence[np.ndarray]], Callable[[Union[np.ndarray, torch.Tensor], Union[str, int]], np.ndarray]]] = None,  # all conf_sets for each null or fun that takes x_obs and null value and returns conf set
    gamma: Optional[float] = None,
    nuisance_bounds: Optional[Sequence[Tuple[float]]] = None,
    opt_method: str = 'diff-evol',  # diff-evol, slsqp, trust-constr if not nuisance_cs. If nuisance_cs is given, either exact-cs or approx-cs
    max_range_expand: int = 10,  # max expand for cutoff range in root finding
    discrete_nuisances: Optional[Sequence] = None,
    verbose: bool = True,
    n_jobs: int = -2,
    **opt_kwargs
) -> np.ndarray:
    assert control in ['fpr', 'tpr', 'power'], f'control: {control}'
    assert nuisance_bounds or nuisance_cs or discrete_nuisances, f"Either `nuisance_cs`, `nuisance_bounds` or `discrete_nuisances` must be provided"
    if gamma:
        assert (gamma < alpha) or math.isclose(gamma, alpha), f'gamma: {gamma:.3f}, alpha: {alpha:.3f}'

    name_map = {0: 'negative', 1: 'positive'}
    sign = 1 if control in ['fpr', 'power'] else -1  # either (min FPR or min POWER) or (max TPR = -min -TPR)
    null = [0] if control in ['fpr', 'tpr'] else [0, 1]
    mu = {'fpr': [0], 'tpr': [1], 'power': [0, 1]}[control]
    if not nuisance_cs:
        # find optimal cutoff without confidence set on nuisances. Only one for FPR/TPR, two for POWER (one for each null)
        if opt_method.lower() == 'l-bfgs-b':
            cutoffs = np.array([sign * minimize(
                fun=lambda *nu: sign * inverse_control_fun(
                    rejection_probs_model, alpha, name_map[null[i]], name_map[mu[i]], np.array(list(*nu)), cutoffs_bounds[null[i]], max_range_expand, verbose
                ),
                x0=np.array([np.mean(bounds) for bounds in nuisance_bounds]),  # initial guess equal to mid point; TODO: not sure if there's a better way
                method='L-BFGS-B',
                bounds=nuisance_bounds,
                **opt_kwargs
            ).fun for i in range(len(null))])
        elif opt_method == 'diff-evol':
            cutoffs = np.array([sign * differential_evolution(
                func=lambda *nu: sign * inverse_control_fun(
                    rejection_probs_model, alpha, name_map[null[i]], name_map[mu[i]], np.array(list(*nu)), cutoffs_bounds[null[i]], max_range_expand, verbose
                ),
                bounds=nuisance_bounds,
                strategy='best1bin',
                init='sobol',
                **opt_kwargs
            ).fun for i in range(len(null))])
        elif opt_method == 'trust-constr':
            cutoffs = np.array([sign * minimize(
                fun=lambda *nu: sign * inverse_control_fun(
                    rejection_probs_model, alpha, name_map[null[i]], name_map[mu[i]], np.array(list(*nu)), cutoffs_bounds[null[i]], max_range_expand, verbose
                ),
                x0=np.array([np.mean(bounds) for bounds in nuisance_bounds]),  # initial guess equal to mid point; TODO: not sure if there's a better way
                method='trust-constr',
                bounds=nuisance_bounds,
                **opt_kwargs
            ).fun for i in range(len(null))])
        elif opt_method == 'enumerate':
            inverse = lambda nu, i: inverse_control_fun(
                rejection_probs_model, alpha, name_map[null[i]], name_map[mu[i]], np.array([nu]), cutoffs_bounds[null[i]], max_range_expand, verbose
            )
            cutoffs = np.array([
                sign * np.min([sign * inverse(nu_val, i) for nu_val in discrete_nuisances]) 
                for i in range(len(null))
            ])
        else:
            raise ValueError(f'Only diff-evol, slsqp, trust-constr and enumerate are currently implemented, got {opt_method}')
    else:
        # find optimal cutoff within confidence set on nuisances. Only one cutoff for FPR/TPR, two for POWER (one for each null)
        assert x_obs.ndim > 1, "x_obs must be two-dimensional, with dim 0 being the number of observations and dim 1 the dimensionality of each observation"
        if isinstance(nuisance_cs, Callable):   # compute confidence sets on the fly
            get_nu_cs = lambda obs_idx, class_idx: nuisance_cs(x_obs[obs_idx, :], null[class_idx])
        else:  # sequence of confidence sets for each null value
            get_nu_cs = lambda obs_idx, class_idx: nuisance_cs[class_idx][obs_idx]

        if opt_method == 'exact-cs':  # confidence set can be have arbitrary shape: compute optimal c as inf/min over all points in confidence set
            def opt_fun(obs_idx, class_idx):
                cs = get_nu_cs(obs_idx, class_idx)
                if len(cs) == 0:
                    if verbose:
                        print('Empty confidence set', flush=True)
                    # search over the whole nuisance parameter space if confidence set is empty TODO: is this okay?
                    cs = np.hstack([np.array(bound) for bound in nuisance_bounds])
                if cs.ndim == 1:
                    cs = np.expand_dims(cs, axis=1)
                inverse = lambda nu: inverse_control_fun(
                    rejection_probs_model, alpha-gamma, name_map[null[class_idx]], name_map[mu[class_idx]], nu, cutoffs_bounds[null[class_idx]], max_range_expand, verbose
                )
                return sign * np.min([sign * inverse(nu_val) for nu_val in cs[::opt_kwargs.pop('subsample_cs', 1)]])
        elif opt_method.split('/')[0] == 'approx-cs':  
            # take smallest hypercube surrounding the confidence set and run differential evolution on it -> hopefully less iterations than exact-cs method
            # TODO: what if confidence set is disconnected? In general, even if not disconnected, if smallest hypercube is very large compared to confidence set we will lose power and be over-confident.
            # Look at constraints for diff-evol: https://stackoverflow.com/questions/43284991/constraints-on-parameters-using-scipy-differential-evolution
            # can also modify the minimized function to be +infinity if considering point outside confidence set. How to check if point is inside or outside?
            def opt_fun(obs_idx, class_idx):
                cs = get_nu_cs(obs_idx, class_idx)
                if len(cs) == 0:
                    if verbose:
                        print('Empty confidence set', flush=True)
                    # searching over the whole nuisance parameter space if confidence set is empty TODO: is this okay?
                    cs = np.hstack([np.array(bound) for bound in nuisance_bounds])
                if cs.ndim == 1:
                    cs = np.expand_dims(cs, axis=1)
                if opt_method.split('/')[1].lower() == 'diff-evol':
                    return sign * differential_evolution(
                        func=lambda *nu: sign * inverse_control_fun(
                            rejection_probs_model, alpha-gamma, name_map[null[class_idx]], name_map[mu[class_idx]], np.array(list(*nu)), cutoffs_bounds[null[class_idx]], max_range_expand, verbose
                        ),
                        bounds=[(np.min(cs[:, dim]), np.max(cs[:, dim])) for dim in range(cs.shape[1])],
                        strategy='best1bin',
                        init=opt_kwargs.pop('init') if 'init' in opt_kwargs else cs,
                        **opt_kwargs
                    ).fun
                elif opt_method.split('/')[1].lower() == 'nelder-mead':
                    return sign * minimize(
                        fun=lambda *nu: sign * inverse_control_fun(
                            rejection_probs_model, alpha-gamma, name_map[null[class_idx]], name_map[mu[class_idx]], np.array(list(*nu)), cutoffs_bounds[null[class_idx]], max_range_expand, verbose
                        ),
                        x0=[np.mean(cs[:, dim]) for dim in range(cs.shape[1])],  # mid-point
                        method='Nelder-Mead',
                        bounds=[(np.min(cs[:, dim]), np.max(cs[:, dim])) for dim in range(cs.shape[1])],
                        **opt_kwargs
                    ).fun
                elif opt_method.split('/')[1].lower() == 'l-bfgs-b':
                    return sign * minimize(
                        fun=lambda *nu: sign * inverse_control_fun(
                            rejection_probs_model, alpha-gamma, name_map[null[class_idx]], name_map[mu[class_idx]], np.array(list(*nu)), cutoffs_bounds[null[class_idx]], max_range_expand, verbose
                        ),
                        x0=[np.mean(cs[:, dim]) for dim in range(cs.shape[1])],  # mid-point
                        method='L-BFGS-B',
                        bounds=[(np.min(cs[:, dim]), np.max(cs[:, dim])) for dim in range(cs.shape[1])],
                        **opt_kwargs
                    ).fun
                else:
                    raise NotImplementedError
        else:
            raise ValueError(f'Only exact-cs and approx-cs are currently implemented, got {opt_method}')
            
        cutoffs = []
        for class_idx in range(len(null)):
            with tqdm_joblib(tqdm(it:=range(x_obs.shape[0]), desc=f"Finding optimal cutoffs for {len(it)} observations...", total=len(it))) as _:
                cutoffs_null = np.array(Parallel(n_jobs=n_jobs)(delayed(lambda obs_idx: opt_fun(obs_idx, class_idx))(j) for j in it)).reshape(len(it), 1)
            cutoffs.append(cutoffs_null)
        cutoffs = np.hstack(cutoffs)

    return cutoffs
