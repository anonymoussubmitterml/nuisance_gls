from typing import Sequence, List
from tqdm import tqdm

import numpy as np
import torch
from torch.nn import BCEWithLogitsLoss
from torch.nn.functional import softmax


class FeedForwardClassifier(torch.nn.Module):
    """Simple Feed-Forward Neural Network for classification with an arbitrary number of hidden layers and units, plus optional dropout regularization.
    """

    def __init__(
        self,
        input_d: int,
        output_d: int,
        hidden_layer_shapes: Sequence[int],
        hidden_activation: torch.nn.Module = torch.nn.ReLU(),
        dropout_p: float = 0.1,
        batch_norm: bool = True
    ) -> None:
        super().__init__()
        self.input_d = input_d
        self.output_d = output_d
        self.hidden_layer_shapes = hidden_layer_shapes
        self.hidden_activation = hidden_activation
        self.dropout_p = dropout_p

        self.build_model(batch_norm)

    def build_model(self, batch_norm: bool) -> None:
        # input
        self.model = [torch.nn.Linear(self.input_d, self.hidden_layer_shapes[0]), self.hidden_activation]
        if batch_norm:
            self.model += [torch.nn.BatchNorm1d(self.hidden_layer_shapes[0])]
        self.model += [torch.nn.Dropout(p=self.dropout_p)]

        # hidden 
        for i in range(0, len(self.hidden_layer_shapes)-1):
            self.model += [torch.nn.Linear(self.hidden_layer_shapes[i], self.hidden_layer_shapes[i+1]), self.hidden_activation]
            if batch_norm:
                self.model += [torch.nn.BatchNorm1d(self.hidden_layer_shapes[i+1])]
            self.model += [torch.nn.Dropout(p=self.dropout_p)]
        # output: no sigmoid cause we use BCEWithLogitsLoss (more numerically stable thanks to log-sum-exp trick)
        self.model += [torch.nn.Linear(self.hidden_layer_shapes[-1], self.output_d)]
        self.model = torch.nn.Sequential(*self.model)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        return self.model(X)
    

class Learner:
    """Implements methods for training and inference.
    """
    def __init__(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        loss: torch.nn.Module = BCEWithLogitsLoss(),
        device: str = "cpu"
    ) -> None:
        self.device = torch.device(device)
        self.model = model.to(self.device)
        self.optimizer = optimizer(self.model.parameters())
        self.loss = loss.to(self.device)
        self.loss_trajectory: List[np.ndarray] = []
    
    def fit(
        self,
        X: torch.Tensor, 
        y: torch.Tensor,
        epochs: int, 
        batch_size: int
    ) -> None:
        self.model.train()
        for _ in tqdm(range(epochs), desc="Training ..."):
            shuffled_idx = torch.randperm(X.shape[0])
            X = X[shuffled_idx, :]
            y = y[shuffled_idx]
            epoch_losses = []
            for idx in range(0, X.shape[0], batch_size):
                self.optimizer.zero_grad()
                
                batch_X_cont = X[idx: min(idx + batch_size, X.shape[0]), :].float().to(self.device)
                batch_y = y[idx: min(idx + batch_size, y.shape[0])].reshape(-1, 1).float().to(self.device)
                
                batch_predictions = self.model(batch_X_cont)
                batch_loss = self.loss(input=batch_predictions, target=batch_y)
                batch_loss.backward()
                self.optimizer.step()
                epoch_losses.append(batch_loss.cpu().detach().numpy())
            self.loss_trajectory.append(np.mean(epoch_losses))
    
    def predict_proba(
        self,
        X: torch.Tensor
    ) -> torch.Tensor:
        self.model.eval()
        return softmax(self.model(X.float().to(self.device)).cpu().detach().reshape(X.shape[0], -1), dim=1)
