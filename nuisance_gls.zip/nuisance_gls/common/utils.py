from typing import Union
import os

import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KernelDensity
from lf2i.inference import LF2I


def select_n_jobs(n_jobs: int):
    if n_jobs < -1:
        n_jobs = max(1, os.cpu_count()+1+n_jobs)
    elif n_jobs == -1:
        n_jobs = os.cpu_count()
    elif n_jobs == 0:
        raise ValueError('n_jobs must be greater than 0')
    else:
        n_jobs = n_jobs
    return n_jobs


def fit_kde(
    X: np.ndarray,
    bandwidth: Union[float, str] = "cv",
    num_cv_folds: int = 5,
    num_cv_reps: int = 5,
    n_jobs: int = -2
) -> KernelDensity:
    """Fit Gaussian Kernel Density Estimator.

    Parameters
    ----------
    X : np.ndarray
        Samples over which KDE is fitted.
    bandwidth : Union[float, str], optional
        Bandwidth method. Either a `float`, 'silverman' or 'scott' heuristics, or 'cv' for cross validation, by default 'cv'.
        Cross validation can be repeated `num_cv_reps` times to “zoom in” and find better bandwidths.
    num_cv_folds : int, optional
        Number of folds for cross validation, by default 5
    num_cv_reps : int, optional
        Number of repetitions of cross validation, by default 5. Used to “zoom into” the bandwidth values and find the optimal one.
    n_jobs : int, optional
        Number of workers to use when doing cross validation. By default -2, which uses all cores minus one.
        `n_jobs == -1` uses all cores. If `n_jobs < -1`, then `n_jobs = os.cpu_count()+1+n_jobs`.

    Returns
    -------
    KernelDensity
        Fitted KDE estimator.

    Raises
    ------
    ValueError
        Bandwidth must be a positive `float`, 'scott', 'silverman' or 'cv'.

    References
    ------
    Adapted from 
        [1]: https://github.com/sbi-dev/sbi/blob/main/sbi/utils/kde.py
        [2]: https://github.com/scikit-learn/scikit-learn/blob/0303fca35e32add9d7346dcb2e0e697d4e68706f/sklearn/neighbors/kde.py
    """
    n_jobs = select_n_jobs(n_jobs)

    if X.ndim == 1:
        X = np.expand_dims(X, axis=1)
    num_samples, dim_samples = X.shape

    if bandwidth == "scott":
        bandwidth_selected = num_samples ** (-1.0 / (dim_samples + 4))
    elif bandwidth == "silverman":
        bandwidth_selected = (num_samples * (dim_samples + 2) / 4.0) ** (
            -1.0 / (dim_samples + 4)
        )
    elif bandwidth == "cv":
        _std = X.std()
        steps = 10
        lower = 0.1 * _std
        upper = 0.5 * _std
        current_best = -np.inf

        # run cv multiple times to "zoom in" and find better bandwidths
        for _ in range(num_cv_reps):
            bandwidth_range = np.linspace(lower, upper, steps)
            grid = GridSearchCV(
                KernelDensity(
                    kernel='gaussian',
                    algorithm='auto',
                    metric='euclidean'
                ),
                {"bandwidth": bandwidth_range},
                cv=num_cv_folds,
                n_jobs=n_jobs
            )
            grid.fit(X)

            # if new best score, update and zoom in. Higher is better since `score` is log-likelihood for kde
            if grid.best_score_ > current_best:
                current_best = grid.best_score_
            else:
                break

            second_best_index = list(grid.cv_results_["rank_test_score"]).index(2)

            # if first or last in grid
            if (grid.best_index_ == 0) or (grid.best_index_ == steps):
                diff = (upper - lower) / steps
                lower = max(0, bandwidth_range[grid.best_index_] - diff)  # must be non-negative
                upper = max(0 + diff, bandwidth_range[grid.best_index_] + diff)
            else:
                upper = bandwidth_range[second_best_index]
                lower = bandwidth_range[grid.best_index_]

                if upper < lower:
                    upper, lower = lower, upper

        bandwidth_selected = grid.best_params_["bandwidth"]
    elif float(bandwidth) > 0:
        bandwidth_selected = float(bandwidth)
    else:
        raise ValueError("bandwidth must be positive `float`, 'scott', 'silverman' or 'cv'")

    # run final fit with selected bandwidth
    kde = KernelDensity(
        kernel='gaussian',
        algorithm='auto',
        metric='euclidean',
        bandwidth=bandwidth_selected,
    )
    kde.fit(X)

    return kde
