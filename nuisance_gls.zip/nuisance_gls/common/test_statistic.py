from typing import Any, Dict, Union, Tuple

import numpy as np
import torch

from lf2i.test_statistics import TestStatistic
from lf2i.utils.miscellanea import to_np_if_torch, check_for_nans


class BayesFactor(TestStatistic):

    def __init__(
        self,
        poi_dim: int,
        estimator: [str, Any],
        estimator_kwargs: Dict = {}
    ) -> None:
        
        super().__init__(acceptance_region='right', estimation_method='classification')
        self.poi_dim = poi_dim
        self.estimator = self._choose_estimator(estimator, estimator_kwargs, 'classification')

    def estimate(
        self,
        poi: Union[np.ndarray, torch.Tensor],
        samples: Union[np.ndarray, torch.Tensor],
    ) -> None:
        poi, samples = preprocess_estimation_evaluation(poi, samples, self.poi_dim, self.estimator)
        self.estimator.fit(X=samples, y=poi)
        self._estimator_trained['classification'] = True
    
    def evaluate(
        self,
        samples: Union[np.ndarray, torch.Tensor]
    ) -> np.ndarray:
        _, samples = preprocess_estimation_evaluation(np.array([]), samples, self.poi_dim, self.estimator)
        probs = to_np_if_torch(self.estimator.predict_proba(X=samples)).reshape(samples.shape[0], -1)
        if (num_poi:=probs.shape[1]) > 1:
            return np.hstack([  # log (p_i / sum_j!=i p_j)
                np.log( (probs[:, i].reshape(-1, 1)/np.sum(probs[:, [j for j in range(num_poi) if j!=i]].reshape(-1, num_poi-1), axis=1).reshape(-1, 1)) ) 
                for i in range(num_poi)
            ])
        else:
            # only probability of positive class is given
            return np.hstack([np.log( (1-probs)/probs ), np.log( probs/(1-probs) )])


class ClfProb(TestStatistic):

    def __init__(
        self,
        poi_dim: int,
        estimator: [str, Any],
        estimator_kwargs: Dict = {}
    ) -> None:
        
        super().__init__(acceptance_region='right', estimation_method='classification')
        self.poi_dim = poi_dim
        self.estimator = self._choose_estimator(estimator, estimator_kwargs, 'classification')

    def estimate(
        self,
        poi: Union[np.ndarray, torch.Tensor],
        samples: Union[np.ndarray, torch.Tensor],
    ) -> None:
        poi, samples = preprocess_estimation_evaluation(poi, samples, self.poi_dim, self.estimator)
        self.estimator.fit(X=samples, y=poi)
        self._estimator_trained['classification'] = True
    
    def evaluate(
        self,
        samples: Union[np.ndarray, torch.Tensor]
    ) -> np.ndarray:
        _, samples = preprocess_estimation_evaluation(np.array([]), samples, self.poi_dim, self.estimator)
        probs = to_np_if_torch(self.estimator.predict_proba(X=samples)).reshape(samples.shape[0], -1)
        if probs.shape[1] > 1:
            return np.log(probs)
        else:  # if only probability of positive class is given
            return np.log(np.hstack([1-probs, probs]))


def preprocess_estimation_evaluation(
    poi: Union[np.ndarray, torch.Tensor],
    samples: Union[np.ndarray, torch.Tensor],
    poi_dim: int,
    estimator: Any
) -> Tuple[Union[np.ndarray, torch.Tensor]]:
    check_for_nans(poi)
    check_for_nans(samples)
    if isinstance(estimator, torch.nn.Module) or (hasattr(estimator, 'model') and isinstance(estimator.model, torch.nn.Module)):
        # PyTorch models
        if isinstance(poi, np.ndarray):
            poi = torch.from_numpy(poi)
        if isinstance(samples, np.ndarray):
            samples = torch.from_numpy(samples)
        if samples.ndim == 1:
            samples = samples.unsqueeze(1)
    else:  # assume anything else works with numpy arrays
        if isinstance(poi, torch.Tensor):
            poi = poi.numpy()
        if isinstance(samples, torch.Tensor):
            samples = samples.numpy()
        if samples.ndim == 1:
            samples = np.expand_dims(samples, axis=1)
    return poi.reshape(-1, poi_dim), samples
