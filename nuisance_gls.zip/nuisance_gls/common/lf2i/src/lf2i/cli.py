import click


@click.group()
def lf2i():
    pass