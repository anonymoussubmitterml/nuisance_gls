from lf2i.inference.lf2i import LF2I

__all__ = ["LF2I"]
