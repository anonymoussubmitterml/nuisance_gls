# Classification under Nuisance Parameters and Generalized Label Shift

## Install

Create a virtual environment and install Python (version `3.11` was used for this work) and the additional dependencies listed under `requirements.txt`. 
If R is not installed, on linux you can do so via
```bash
sudo apt update
sudo apt install r-base r-base-dev -y
```
Then install the `lf2i` submodule by `cd`-ing into `common/lf2i` and running `pip install .`.